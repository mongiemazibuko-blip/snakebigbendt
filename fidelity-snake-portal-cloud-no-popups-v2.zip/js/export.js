/* Exports: Excel, PDF, PowerPoint, KML/KMZ. Uses REPORTS, fmtDate, locLabel, mapsLink, esc, toast, modal from app.js */
function download(blob, name) {
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name;
  document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}
const stamp = () => fmtDate(new Date().toISOString());
const baseName = () => `Fidelity_Eswatini_Bigbend_Snake_Reports_${stamp()}`;

async function runExport(kind) {
  if (window.DB && DB.mode === 'cloud' && DB.photosPending && DB.photosPending() > 0) {
    toast('Loading photos from the cloud first...');
    await DB.waitPhotos(); try { await refresh(); } catch (e) { /* use what we have */ }
  }
  if (!REPORTS.length) return toast('There are no reports to export yet.', true);
  const need = { xlsx: 'XLSX', pdf: 'jspdf', pptx: 'PptxGenJS', kml: null }[kind];
  if (need && typeof window[need] === 'undefined') return toast('Export library could not load. Check your internet connection and reload.', true);
  try {
    if (kind === 'xlsx') exportXlsx();
    else if (kind === 'pdf') exportPdf();
    else if (kind === 'pptx') exportPptx();
    else if (kind === 'kml') kmlChoice();
  } catch (e) { console.error(e); toast('Export failed: ' + e.message, true); }
}

/* ---------- Excel ---------- */
function weekKey(iso) {
  const d = new Date(iso); const t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const day = t.getUTCDay() || 7; t.setUTCDate(t.getUTCDate() + 4 - day);
  const y0 = new Date(Date.UTC(t.getUTCFullYear(), 0, 1));
  return `${t.getUTCFullYear()}-W${String(Math.ceil(((t - y0) / 864e5 + 1) / 7)).padStart(2, '0')}`;
}
function countBy(fn) {
  const m = {}; REPORTS.forEach(r => { const k = fn(r); m[k] = m[k] || { Captured: 0, Released: 0 }; m[k][r.status === 'Released' ? 'Released' : 'Captured']++; });
  return Object.keys(m).sort().map(k => ({ Period: k, Captured: m[k].Captured, Released: m[k].Released, Total: m[k].Captured + m[k].Released }));
}
function exportXlsx() {
  const rows = REPORTS.map(r => ({
    'Report ID': r.id, 'Date captured': fmtDate(r.capturedAt, true), 'Catcher': r.catcher, 'Employee No': r.empNo,
    'Status': r.status, 'Site / area': r.site || '', 'Latitude': r.lat, 'Longitude': r.lng, 'Release location': r.releaseLoc || '',
    'Date released': fmtDate(r.releasedAt, true), 'Description': r.description, 'Google Maps': mapsLink(r), 'Logged by': r.createdBy || '', 'Environment': r.environment || ''
  }));
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(rows);
  ws['!cols'] = [14, 17, 22, 14, 11, 20, 11, 11, 24, 17, 60, 38, 14, 12].map(w => ({ wch: w }));
  ws['!autofilter'] = { ref: ws['!ref'] };
  XLSX.utils.book_append_sheet(wb, ws, 'Reports');
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(countBy(r => fmtDate(r.capturedAt))), 'Daily count');
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(countBy(r => weekKey(r.capturedAt))), 'Weekly count');
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(countBy(r => fmtDate(r.capturedAt).slice(0, 7))), 'Monthly count');
  XLSX.writeFile(wb, baseName() + '.xlsx');
  toast('Excel file downloaded.');
}

/* ---------- PDF ---------- */
function exportPdf() {
  const { jsPDF } = window.jspdf; const doc = new jsPDF({ unit: 'mm', format: 'a4' });
  const W = 210, M = 14; let y = 0;
  const head = () => {
    doc.setFillColor(20, 99, 31); doc.rect(0, 0, W, 22, 'F');
    doc.setTextColor(255); doc.setFont('helvetica', 'bold'); doc.setFontSize(15); doc.text('Fidelity Services Group - Eswatini (Bigbend) - Snake Catchers Report', M, 10);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(9.5); doc.text('Report - Protect - Preserve     Generated ' + fmtDate(new Date().toISOString(), true), M, 16.5);
    doc.setTextColor(30); y = 30;
  };
  head();
  const cap = REPORTS.filter(r => r.status !== 'Released').length, rel = REPORTS.length - cap;
  doc.setFontSize(11); doc.setFont('helvetica', 'bold'); doc.text(`Total ${REPORTS.length}   |   Captured ${cap}   |   Released ${rel}`, M, y); y += 8;
  REPORTS.forEach(r => {
    const h = 52;
    if (y + h > 285) { doc.addPage(); head(); }
    doc.setDrawColor(190, 205, 192); doc.rect(M, y, W - 2 * M, h);
    if (r.photo) { try { doc.addImage(r.photo, 'JPEG', M + 2, y + 2, 64, 48); } catch (e) { /* skip bad image */ } }
    else { doc.setFillColor(240, 244, 240); doc.rect(M + 2, y + 2, 64, 48, 'F'); doc.setFontSize(9); doc.setFont('helvetica', 'normal'); doc.text('No photo', M + 28, y + 27); }
    const x = M + 70; let ty = y + 7;
    doc.setFont('helvetica', 'bold'); doc.setFontSize(11);
    doc.setTextColor(r.status === 'Released' ? 46 : 200, r.status === 'Released' ? 158 : 40, r.status === 'Released' ? 60 : 40); doc.text(r.status.toUpperCase(), x, ty);
    doc.setTextColor(30); doc.text(fmtDate(r.capturedAt, true), x + 32, ty); ty += 6;
    doc.setFont('helvetica', 'normal'); doc.setFontSize(9.5);
    const lines = [`Catcher: ${r.catcher} (${r.empNo})`];
    if (r.site) lines.push('Site: ' + r.site);
    if (r.lat != null) lines.push(`GPS: ${(+r.lat).toFixed(5)}, ${(+r.lng).toFixed(5)}`);
    if (r.releaseLoc) lines.push('Release: ' + r.releaseLoc + (r.releasedAt ? ' (' + fmtDate(r.releasedAt, true) + ')' : ''));
    lines.forEach(l => { doc.text(doc.splitTextToSize(l, W - x - M - 2)[0], x, ty); ty += 5; });
    const d = doc.splitTextToSize('Description: ' + r.description, W - x - M - 2).slice(0, 5); doc.text(d, x, ty);
    y += h + 5;
  });
  const n = doc.getNumberOfPages();
  for (let i = 1; i <= n; i++) { doc.setPage(i); doc.setFontSize(8.5); doc.setTextColor(110); doc.text(`Fidelity Services Group - Eswatini (Bigbend)     Page ${i} of ${n}`, M, 292); }
  doc.save(baseName() + '.pdf'); toast('PDF downloaded.');
}

/* ---------- PowerPoint ---------- */
function exportPptx() {
  const p = new PptxGenJS(); p.layout = 'LAYOUT_WIDE'; p.title = 'Fidelity Services Group - Eswatini (Bigbend) Snake Catchers Report';
  const G = '14631F', F = 'Calibri';
  const cap = REPORTS.filter(r => r.status !== 'Released').length, rel = REPORTS.length - cap;
  let s = p.addSlide(); s.background = { color: G };
  s.addText('Fidelity Services Group - Eswatini (Bigbend)', { x: .7, y: 1.6, w: 12, h: 1, fontSize: 36, bold: true, color: 'FFFFFF', fontFace: F });
  s.addText('Snake Catchers Report', { x: .7, y: 2.6, w: 12, h: .9, fontSize: 34, color: 'FFFFFF', fontFace: F });
  s.addText('Report  \u2022  Protect  \u2022  Preserve', { x: .7, y: 3.6, w: 12, h: .6, fontSize: 20, italic: true, color: 'D6EAD2', fontFace: F });
  s.addText('Generated ' + fmtDate(new Date().toISOString(), true), { x: .7, y: 6.5, w: 8, h: .4, fontSize: 14, color: 'D6EAD2', fontFace: F });

  s = p.addSlide(); s.addText('Summary', { x: .6, y: .35, w: 8, h: .7, fontSize: 30, bold: true, color: G, fontFace: F });
  [['Total reports', REPORTS.length, '1B7A28'], ['Captured', cap, '1565C0'], ['Released', rel, 'EF8A17']].forEach((c, i) => {
    s.addShape(p.ShapeType.rect, { x: .6 + i * 4.1, y: 1.3, w: 3.8, h: 1.6, fill: { color: c[2] } });
    s.addText(String(c[1]), { x: .6 + i * 4.1, y: 1.35, w: 3.8, h: 1, fontSize: 48, bold: true, color: 'FFFFFF', align: 'center', fontFace: F });
    s.addText(c[0], { x: .6 + i * 4.1, y: 2.3, w: 3.8, h: .5, fontSize: 18, color: 'FFFFFF', align: 'center', fontFace: F });
  });
  const monthly = countBy(r => fmtDate(r.capturedAt).slice(0, 7)).slice(-8);
  const tbl = [[{ text: 'Month', options: { bold: true, fill: { color: 'E3F3E0' } } }, { text: 'Captured', options: { bold: true, fill: { color: 'E3F3E0' } } }, { text: 'Released', options: { bold: true, fill: { color: 'E3F3E0' } } }, { text: 'Total', options: { bold: true, fill: { color: 'E3F3E0' } } }]]
    .concat(monthly.map(m => [m.Period, String(m.Captured), String(m.Released), String(m.Total)]));
  s.addTable(tbl, { x: .6, y: 3.3, w: 8, fontSize: 14, fontFace: F, border: { type: 'solid', color: 'CFD9D1', pt: 1 } });

  REPORTS.forEach(r => {
    const sl = p.addSlide();
    sl.addShape(p.ShapeType.rect, { x: 0, y: 0, w: 13.33, h: .9, fill: { color: G } });
    sl.addText(`${r.status}  |  ${locLabel(r)}`, { x: .5, y: .1, w: 12.3, h: .7, fontSize: 24, bold: true, color: 'FFFFFF', fontFace: F });
    if (r.photo) sl.addImage({ data: r.photo, x: .5, y: 1.2, w: 6.2, h: 4.65, sizing: { type: 'contain', w: 6.2, h: 4.65 } });
    else sl.addText('No photo', { x: .5, y: 1.2, w: 6.2, h: 4.65, align: 'center', color: '888888', fill: { color: 'F0F4F0' }, fontFace: F });
    const det = [['Catcher', `${r.catcher} (${r.empNo})`], ['Captured', fmtDate(r.capturedAt, true)], ['GPS', r.lat != null ? `${(+r.lat).toFixed(5)}, ${(+r.lng).toFixed(5)}` : '-'],
      ['Release location', r.releaseLoc || '-'], ['Released', fmtDate(r.releasedAt, true) || '-']];
    sl.addText(det.map(d => ({ text: d[0] + ': ', options: { bold: true, color: G, breakLine: false } })).flatMap((t, i) => [t, { text: det[i][1], options: { breakLine: true } }]),
      { x: 7.1, y: 1.2, w: 5.8, h: 2.6, fontSize: 16, fontFace: F, valign: 'top', paraSpaceAfter: 6 });
    sl.addText([{ text: 'Description', options: { bold: true, color: G, breakLine: true } }, { text: r.description.slice(0, 600) }], { x: 7.1, y: 3.9, w: 5.8, h: 2.3, fontSize: 15, fontFace: F, valign: 'top' });
    sl.addText('Fidelity Services Group - Eswatini (Bigbend)', { x: .5, y: 7, w: 8, h: .3, fontSize: 10, color: '777777', fontFace: F });
  });
  p.writeFile({ fileName: baseName() + '.pptx' }).then(() => toast('PowerPoint downloaded.'));
}

/* ---------- KML / KMZ ---------- */
function kmlChoice() {
  const withGps = REPORTS.filter(r => r.lat != null && !isNaN(r.lat)).length;
  if (!withGps) return toast('None of the reports have GPS coordinates to export.', true);
  modal('Export to Google Earth', `<p style="margin-top:0">${withGps} reports with GPS will be exported.</p><div style="display:grid;gap:10px">
    <button class="btn blue" id="kz">KMZ with snake photos (recommended)</button><button class="btn grey" id="kk">KML only (no photos)</button></div>`,
    (root, close) => { root.querySelector('#kz').onclick = () => { close(); buildKml(true); }; root.querySelector('#kk').onclick = () => { close(); buildKml(false); }; });
}
function buildKml(kmz) {
  if (kmz && typeof JSZip === 'undefined') return toast('Could not load the ZIP library. Try the KML-only option.', true);
  const x = s => String(s == null ? '' : s).replace(/[<>&]/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' }[c]));
  const zip = kmz ? new JSZip() : null;
  const style = (id, col) => `<Style id="${id}"><IconStyle><scale>1.2</scale><Icon><href>http://maps.google.com/mapfiles/kml/paddle/${col}-circle.png</href></Icon></IconStyle></Style>`;
  let pm = '';
  REPORTS.filter(r => r.lat != null && !isNaN(r.lat)).forEach(r => {
    let img = '';
    if (kmz && r.photo) { zip.file(`images/${r.id}.jpg`, r.photo.split(',')[1], { base64: true }); img = `<img src="images/${r.id}.jpg" width="320"/><br/>`; }
    const desc = `<![CDATA[${img}<b>Status:</b> ${esc(r.status)}<br/><b>Catcher:</b> ${esc(r.catcher)} (${esc(r.empNo)})<br/><b>Captured:</b> ${fmtDate(r.capturedAt, true)}<br/>` +
      (r.site ? `<b>Site:</b> ${esc(r.site)}<br/>` : '') + (r.releaseLoc ? `<b>Release location:</b> ${esc(r.releaseLoc)}<br/>` : '') +
      (r.releasedAt ? `<b>Released:</b> ${fmtDate(r.releasedAt, true)}<br/>` : '') + `<b>GPS:</b> ${(+r.lat).toFixed(6)}, ${(+r.lng).toFixed(6)}<br/><b>Description:</b> ${esc(r.description)}]]>`;
    pm += `<Placemark><name>${x(r.status)} - ${x(locLabel(r))}</name><styleUrl>#${r.status === 'Released' ? 'rel' : 'cap'}</styleUrl>` +
      `<TimeStamp><when>${new Date(r.capturedAt).toISOString()}</when></TimeStamp><description>${desc}</description>` +
      `<Point><coordinates>${r.lng},${r.lat},0</coordinates></Point></Placemark>\n`;
  });
  const kml = `<?xml version="1.0" encoding="UTF-8"?>\n<kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>Fidelity Services Group - Eswatini (Bigbend) Snake Catchers</name>` +
    `<description>Generated ${fmtDate(new Date().toISOString(), true)}</description>${style('cap', 'red')}${style('rel', 'grn')}\n${pm}</Document></kml>`;
  if (kmz) { zip.file('doc.kml', kml); zip.generateAsync({ type: 'blob', compression: 'DEFLATE' }).then(b => { download(b, baseName() + '.kmz'); toast('KMZ downloaded. Open it in Google Earth.'); }); }
  else { download(new Blob([kml], { type: 'application/vnd.google-earth.kml+xml' }), baseName() + '.kml'); toast('KML downloaded.'); }
}
