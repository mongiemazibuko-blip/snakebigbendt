/* Fidelity Services Group - Eswatini (Bigbend) Snake Catchers Portal - shared cloud database API
   Cloudflare Pages "advanced mode" worker (single file, no build step) + D1 database.
   Binding required in the Pages project:  D1 database  ->  variable name  PORTAL_DB
   Optional environment variables:  ADMIN_PASSWORD, ADMIN_USERNAME (first-run admin), PBKDF2_ITER (default 10000),
   MAX_USER_DEVICES (default 2 - devices a normal user may be signed in on; administrators are never limited)
   All requests reach this worker; non-API ones are passed straight to the static files (env.ASSETS). */

const enc = new TextEncoder();
const DEFAULT_ADMIN = { username: 'Mongi', name: 'Mongi Mazibuko', empNo: 'FSG-496', password: 'Toor007' };
const SESSION_DAYS = 30;
const DEVICE_RE = /^[a-f0-9]{16,64}$/;
const maxDevices = env => Math.min(20, Math.max(1, parseInt(env.MAX_USER_DEVICES || '2', 10) || 2));

const SCHEMA = [
  `CREATE TABLE IF NOT EXISTS users (
     key TEXT PRIMARY KEY, username TEXT NOT NULL, name TEXT NOT NULL DEFAULT '', emp_no TEXT NOT NULL DEFAULT '',
     role TEXT NOT NULL DEFAULT 'user', salt TEXT NOT NULL, hash TEXT NOT NULL,
     algo TEXT NOT NULL DEFAULT 'pbkdf2', iter INTEGER NOT NULL DEFAULT 10000, created TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS sessions (
     token_hash TEXT PRIMARY KEY, user_key TEXT NOT NULL, created INTEGER NOT NULL, expires INTEGER NOT NULL, ua TEXT)`,
  `CREATE TABLE IF NOT EXISTS reports (
     id TEXT PRIMARY KEY, catcher TEXT NOT NULL DEFAULT '', emp_no TEXT NOT NULL DEFAULT '',
     lat REAL, lng REAL, release_lat REAL, release_lng REAL,
     site TEXT NOT NULL DEFAULT '', release_loc TEXT NOT NULL DEFAULT '', description TEXT NOT NULL DEFAULT '',
     status TEXT NOT NULL DEFAULT 'Captured', captured_at TEXT, released_at TEXT,
     created_by TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
     environment TEXT NOT NULL DEFAULT '',
     photo TEXT, has_photo INTEGER NOT NULL DEFAULT 0, photo_rev TEXT)`,
  `CREATE TABLE IF NOT EXISTS activity_log (
     id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, username TEXT NOT NULL DEFAULT '',
     action TEXT NOT NULL, detail TEXT NOT NULL DEFAULT '', report_id TEXT)`,
  `CREATE TABLE IF NOT EXISTS login_attempts (k TEXT PRIMARY KEY, n INTEGER NOT NULL DEFAULT 0, until INTEGER NOT NULL DEFAULT 0)`,
  `CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v INTEGER NOT NULL DEFAULT 0)`,
  `INSERT OR IGNORE INTO meta (k, v) VALUES ('rev', 0)`,
  `CREATE INDEX IF NOT EXISTS idx_reports_captured ON reports(captured_at)`,
  `CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_key)`,
  `CREATE INDEX IF NOT EXISTS idx_activity_at ON activity_log(at)`
];

/* ---------- helpers ---------- */
class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const fail = (s, m) => { throw new HttpError(s, m); };
const J = (data, status = 200) => new Response(JSON.stringify(data), {
  status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' }
});
const hex = buf => Array.from(new Uint8Array(buf), b => b.toString(16).padStart(2, '0')).join('');
const rndHex = n => hex(crypto.getRandomValues(new Uint8Array(n)));
const sha256hex = async s => hex(await crypto.subtle.digest('SHA-256', enc.encode(s)));
const keyOf = u => String(u == null ? '' : u).trim().toLowerCase();
const nowIso = () => new Date().toISOString();
const str = (v, max) => String(v == null ? '' : v).slice(0, max);
const num = v => (v === null || v === undefined || v === '' || isNaN(+v)) ? null : +v;
const eq = (a, b) => { a = String(a); b = String(b); if (a.length !== b.length) return false; let d = 0; for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i); return d === 0; };
const ITER = env => Math.min(100000, Math.max(1000, parseInt(env.PBKDF2_ITER || '10000', 10) || 10000));

async function pbkdf2(pw, saltHex, iter) {
  const key = await crypto.subtle.importKey('raw', enc.encode(pw), 'PBKDF2', false, ['deriveBits']);
  const salt = Uint8Array.from((saltHex.match(/.{2}/g) || []).map(h => parseInt(h, 16)));
  return hex(await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: iter }, key, 256));
}
/* hash scheme used by the old per-browser portal (so users migrated from a device can still sign in once) */
async function legacyHash(pw, salt) {
  let buf = await crypto.subtle.digest('SHA-256', enc.encode(salt + ':' + pw));
  for (let i = 0; i < 5000; i++) buf = await crypto.subtle.digest('SHA-256', buf);
  return hex(buf);
}
async function makeHash(env, pw) { const salt = rndHex(16), iter = ITER(env); return { salt, iter, algo: 'pbkdf2', hash: await pbkdf2(pw, salt, iter) }; }
async function verifyPw(u, pw) {
  return u.algo === 'legacy' ? eq(await legacyHash(pw, u.salt), u.hash) : eq(await pbkdf2(pw, u.salt, u.iter || 10000), u.hash);
}
const pub = r => ({ key: r.key, username: r.username, name: r.name, empNo: r.emp_no, role: r.role, created: r.created });

/* ---------- schema + first-run admin ---------- */
let ready = null;
function ensure(env) {
  if (!ready) {
    ready = (async () => {
      const db = env.PORTAL_DB;
      await db.batch(SCHEMA.map(s => db.prepare(s)));
      // device limit: add the device_id column to databases created before this version
      try { await db.prepare('ALTER TABLE sessions ADD COLUMN device_id TEXT').run(); } catch (e) { /* column already exists */ }
      try { await db.prepare("ALTER TABLE reports ADD COLUMN environment TEXT NOT NULL DEFAULT ''").run(); } catch (e) { /* column already exists */ }
      try { await db.prepare('CREATE INDEX IF NOT EXISTS idx_sessions_device ON sessions(user_key, device_id)').run(); } catch (e) { /* ignore */ }
      const c = await db.prepare('SELECT COUNT(*) AS n FROM users').first();
      if (!c || !c.n) {
        const a = DEFAULT_ADMIN, uname = env.ADMIN_USERNAME || a.username, pw = env.ADMIN_PASSWORD || a.password;
        const h = await makeHash(env, pw);
        await db.prepare('INSERT OR IGNORE INTO users (key,username,name,emp_no,role,salt,hash,algo,iter,created) VALUES (?,?,?,?,?,?,?,?,?,?)')
          .bind(keyOf(uname), uname, a.name, a.empNo, 'admin', h.salt, h.hash, h.algo, h.iter, nowIso()).run();
      }
    })().catch(e => { ready = null; throw e; });
  }
  return ready;
}

/* ---------- auth ---------- */
async function authUser(request, env) {
  const m = /^Bearer\s+([a-f0-9]{64})$/i.exec(request.headers.get('authorization') || '');
  if (!m) return null;
  const th = await sha256hex(m[1].toLowerCase());
  const r = await env.PORTAL_DB.prepare(
    'SELECT u.key, u.username, u.name, u.emp_no, u.role, u.created, s.expires FROM sessions s JOIN users u ON u.key = s.user_key WHERE s.token_hash = ?').bind(th).first();
  if (!r || r.expires < Date.now()) return null;
  const u = pub(r); u._th = th; return u;
}
async function logActivity(db, username, action, detail, reportId) {
  await db.prepare('INSERT INTO activity_log (at, username, action, detail, report_id) VALUES (?,?,?,?,?)')
    .bind(nowIso(), str(username, 60), str(action, 40), str(detail, 300), reportId || null).run();
  if (Math.random() < 0.02) await db.prepare('DELETE FROM activity_log WHERE id NOT IN (SELECT id FROM activity_log ORDER BY id DESC LIMIT 5000)').run();
}
async function lockCheck(db, k) {
  const r = await db.prepare('SELECT n, until FROM login_attempts WHERE k = ?').bind(k).first();
  if (r && r.until > Date.now()) fail(429, `Too many failed attempts. Try again in ${Math.ceil((r.until - Date.now()) / 1000)} seconds.`);
}
async function lockFail(db, k, limit, secs) {
  const r = await db.prepare('SELECT n FROM login_attempts WHERE k = ?').bind(k).first();
  const n = (r ? r.n : 0) + 1, hit = n >= limit;
  await db.prepare('INSERT INTO login_attempts (k, n, until) VALUES (?,?,?) ON CONFLICT(k) DO UPDATE SET n = excluded.n, until = excluded.until')
    .bind(k, hit ? 0 : n, hit ? Date.now() + secs * 1000 : 0).run();
}
async function adminCount(db) { return (await db.prepare("SELECT COUNT(*) AS n FROM users WHERE role = 'admin'").first()).n; }

/* ---------- reports ---------- */
const REP_COLS = 'id,catcher,emp_no,lat,lng,release_lat,release_lng,site,release_loc,description,status,captured_at,released_at,created_by,created_at,updated_at,environment,has_photo,photo_rev';
const repOut = r => ({
  id: r.id, catcher: r.catcher, empNo: r.emp_no, lat: r.lat, lng: r.lng, releaseLat: r.release_lat, releaseLng: r.release_lng,
  site: r.site, releaseLoc: r.release_loc, description: r.description, status: r.status,
  capturedAt: r.captured_at, releasedAt: r.released_at, createdBy: r.created_by, createdAt: r.created_at, updatedAt: r.updated_at, environment: r.environment || '', photoRev: r.photo_rev || null, has_photo: !!r.has_photo
});
const REPORT_ID = /^[A-Za-z0-9_-]{3,64}$/;
const MAX_PHOTO = 1800000; // D1 rows are limited to 2 MB

async function putReport(db, me, id, b) {
  if (!REPORT_ID.test(id)) fail(400, 'Bad report id.');
  const ex = await db.prepare('SELECT created_by, created_at FROM reports WHERE id = ?').bind(id).first();
  const isAdmin = me.role === 'admin', now = nowIso();
  const createdBy = ex ? (isAdmin && b.createdBy ? str(b.createdBy, 60) : ex.created_by) : (isAdmin && b.createdBy ? str(b.createdBy, 60) : me.username);
  const createdAt = ex ? ex.created_at : (isAdmin && b.createdAt ? str(b.createdAt, 40) : now);
  const hasKey = Object.prototype.hasOwnProperty.call(b, 'photo');
  let photo = null;
  if (hasKey && typeof b.photo === 'string' && b.photo) {
    if (!b.photo.startsWith('data:image/')) fail(400, 'Photo must be an image.');
    if (b.photo.length > MAX_PHOTO) fail(413, 'Photo is too large (max about 1.8 MB). Choose a smaller photo.');
    photo = b.photo;
  }
  const status = b.status === 'Released' ? 'Released' : 'Captured';
  await db.prepare(
    `INSERT INTO reports (id,catcher,emp_no,lat,lng,release_lat,release_lng,site,release_loc,description,status,captured_at,released_at,created_by,created_at,updated_at,environment,photo,has_photo,photo_rev)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
     ON CONFLICT(id) DO UPDATE SET catcher=excluded.catcher, emp_no=excluded.emp_no, lat=excluded.lat, lng=excluded.lng,
       release_lat=excluded.release_lat, release_lng=excluded.release_lng, site=excluded.site, release_loc=excluded.release_loc,
       description=excluded.description, status=excluded.status, captured_at=excluded.captured_at, released_at=excluded.released_at,
       created_by=excluded.created_by, updated_at=excluded.updated_at,
       environment=CASE WHEN excluded.environment <> '' THEN excluded.environment ELSE reports.environment END,
       photo = CASE WHEN ?21 = 1 THEN excluded.photo ELSE reports.photo END,
       has_photo = CASE WHEN ?21 = 1 THEN excluded.has_photo ELSE reports.has_photo END,
       photo_rev = CASE WHEN ?21 = 1 THEN excluded.photo_rev ELSE reports.photo_rev END`)
    .bind(id, str(b.catcher, 120), str(b.empNo, 60), num(b.lat), num(b.lng), num(b.releaseLat), num(b.releaseLng),
      str(b.site, 200), str(b.releaseLoc, 200), str(b.description, 4000), status, b.capturedAt ? str(b.capturedAt, 40) : now,
      b.releasedAt ? str(b.releasedAt, 40) : null, createdBy, createdAt, now, str(b.environment, 20), photo, photo ? 1 : 0, photo ? now : null, hasKey ? 1 : 0).run();
  return now;
}

/* ---------- router ---------- */
async function route(request, env, url) {
  const p = url.pathname.replace(/\/+$/, '');
  const m = request.method;
  const seg = p.split('/').slice(2);                       // after /api
  const body = async () => { try { return await request.json(); } catch (e) { return fail(400, 'Invalid request body.'); } };

  if (p === '/api/health') {
    if (!env.PORTAL_DB) return J({ ok: true, cloud: true, db: false, error: 'D1 binding PORTAL_DB is not connected to this Pages project.' });
    try { await ensure(env); return J({ ok: true, cloud: true, db: true }); }
    catch (e) { return J({ ok: true, cloud: true, db: false, error: 'Database error: ' + (e && e.message || e) }); }
  }
  if (!env.PORTAL_DB) fail(503, 'The cloud database is not connected (D1 binding PORTAL_DB missing).');
  const db = env.PORTAL_DB;
  await ensure(env);

  /* ----- login ----- */
  if (p === '/api/login' && m === 'POST') {
    const b = await body(), key = keyOf(b.username), pw = String(b.password || '');
    if (!key || !pw) fail(400, 'Enter your username and password.');
    const ip = request.headers.get('CF-Connecting-IP') || 'x';
    await lockCheck(db, 'u:' + key); await lockCheck(db, 'ip:' + ip);
    const u = await db.prepare('SELECT * FROM users WHERE key = ?').bind(key).first();
    let ok = false;
    if (u) ok = await verifyPw(u, pw); else await pbkdf2(pw, '00'.repeat(16), ITER(env)); // equalise timing
    if (!ok) { await lockFail(db, 'u:' + key, 5, 60); await lockFail(db, 'ip:' + ip, 25, 60); fail(401, 'Incorrect username or password.'); }
    await db.prepare('DELETE FROM login_attempts WHERE k = ?').bind('u:' + key).run();
    if (u.algo === 'legacy') {             // upgrade old hash to PBKDF2 on first successful login
      const h = await makeHash(env, pw);
      await db.prepare('UPDATE users SET salt=?, hash=?, algo=?, iter=? WHERE key=?').bind(h.salt, h.hash, h.algo, h.iter, u.key).run();
    }
    const token = rndHex(32), now = Date.now();
    const devId = DEVICE_RE.test(String(b.deviceId || '')) ? String(b.deviceId).toLowerCase() : null;
    if (u.role !== 'admin') {              // normal users: limited number of devices; administrators: unlimited
      if (!devId) fail(400, 'Device could not be identified. Refresh the page and try again.');
      await db.prepare('DELETE FROM sessions WHERE user_key = ? AND expires < ?').bind(u.key, now).run();
      const act = (await db.prepare('SELECT DISTINCT COALESCE(device_id, token_hash) AS dev FROM sessions WHERE user_key = ?').bind(u.key).all()).results.map(r => r.dev);
      const limit = maxDevices(env);
      if (!act.includes(devId) && act.length >= limit)
        fail(403, `Device limit reached: this account is already signed in on ${limit} devices. Sign out on one of them, or ask an administrator to release a device.`);
    }
    if (devId) await db.prepare('DELETE FROM sessions WHERE user_key = ? AND device_id = ?').bind(u.key, devId).run();   // one session per device
    await db.prepare('INSERT INTO sessions (token_hash, user_key, created, expires, ua, device_id) VALUES (?,?,?,?,?,?)')
      .bind(await sha256hex(token), u.key, now, now + SESSION_DAYS * 864e5, str(request.headers.get('user-agent'), 120), devId).run();
    if (Math.random() < 0.1) await db.prepare('DELETE FROM sessions WHERE expires < ?').bind(now).run();
    await logActivity(db, u.username, 'login', 'Signed in');
    return J({ token, user: pub(u) });
  }

  const me = await authUser(request, env);
  if (!me) fail(401, 'Please sign in.');
  const isAdmin = me.role === 'admin';
  const needAdmin = () => { if (!isAdmin) fail(403, 'Administrator access required.'); };

  switch (seg[0]) {
    case 'rev': {    // cheap change counter: devices poll this instead of downloading every report
      const r = await db.prepare("SELECT v FROM meta WHERE k = 'rev'").first();
      return J({ rev: r ? r.v : 0 });
    }

    case 'logout':
      await db.prepare('DELETE FROM sessions WHERE token_hash = ?').bind(me._th).run();
      return J({ ok: true });

    case 'me': {
      if (!seg[1]) { delete me._th; return J({ user: me }); }
      if (seg[1] === 'password' && m === 'POST') {
        const b = await body(), next = String(b.next || '');
        if (next.length < 6) fail(400, 'Password must be at least 6 characters.');
        const u = await db.prepare('SELECT * FROM users WHERE key = ?').bind(me.key).first();
        if (!u || !(await verifyPw(u, String(b.current || '')))) fail(400, 'Current password is incorrect.');
        const h = await makeHash(env, next);
        await db.batch([
          db.prepare('UPDATE users SET salt=?, hash=?, algo=?, iter=? WHERE key=?').bind(h.salt, h.hash, h.algo, h.iter, me.key),
          db.prepare('DELETE FROM sessions WHERE user_key = ? AND token_hash <> ?').bind(me.key, me._th)
        ]);
        await logActivity(db, me.username, 'password_change', 'Own password changed');
        return J({ ok: true });
      }
      break;
    }

    case 'users': {
      if (!seg[1] && m === 'GET') {
        const rows = (await db.prepare('SELECT key, username, name, emp_no, role, created FROM users ORDER BY name').all()).results;
        const out = rows.map(pub);
        if (isAdmin) {
          const dc = (await db.prepare('SELECT user_key, COUNT(DISTINCT COALESCE(device_id, token_hash)) AS n FROM sessions WHERE expires > ? GROUP BY user_key').bind(Date.now()).all()).results;
          const map = {}; dc.forEach(r => { map[r.user_key] = r.n; });
          out.forEach(u => { u.devices = map[u.key] || 0; u.maxDevices = u.role === 'admin' ? null : maxDevices(env); });
        }
        return J({ users: out });
      }
      if (!seg[1] && m === 'POST') {
        needAdmin();
        const b = await body(), key = keyOf(b.username), pw = String(b.password || '');
        if (!/^[a-z0-9._-]{3,30}$/.test(key)) fail(400, 'Username: 3-30 letters, numbers, dot, dash or underscore.');
        if (pw.length < 6) fail(400, 'Password must be at least 6 characters.');
        if (await db.prepare('SELECT 1 AS x FROM users WHERE key = ?').bind(key).first()) fail(409, 'That username already exists.');
        const h = await makeHash(env, pw);
        await db.prepare('INSERT INTO users (key,username,name,emp_no,role,salt,hash,algo,iter,created) VALUES (?,?,?,?,?,?,?,?,?,?)')
          .bind(key, str(b.username, 30).trim(), str(b.name || b.username, 80).trim(), str(b.empNo, 40).trim(), b.role === 'admin' ? 'admin' : 'user', h.salt, h.hash, h.algo, h.iter, nowIso()).run();
        await logActivity(db, me.username, 'user_add', key);
        return J({ ok: true });
      }
      const key = keyOf(decodeURIComponent(seg[1] || ''));
      const target = key ? await db.prepare('SELECT * FROM users WHERE key = ?').bind(key).first() : null;
      if (!target) fail(404, 'User not found.');
      if (seg[2] === 'devices') {
        needAdmin();
        if (m === 'GET') {
          const rows = (await db.prepare('SELECT COALESCE(device_id, token_hash) AS dev, MAX(created) AS last_login, MAX(ua) AS ua FROM sessions WHERE user_key = ? AND expires > ? GROUP BY dev ORDER BY last_login DESC')
            .bind(key, Date.now()).all()).results;
          return J({ devices: rows.map(r => ({ id: r.dev, lastLogin: new Date(r.last_login).toISOString(), ua: r.ua || '' })), max: target.role === 'admin' ? null : maxDevices(env) });
        }
        if (m === 'DELETE') {
          if (seg[3]) await db.prepare('DELETE FROM sessions WHERE user_key = ? AND COALESCE(device_id, token_hash) = ?').bind(key, decodeURIComponent(seg[3])).run();
          else await db.prepare('DELETE FROM sessions WHERE user_key = ?').bind(key).run();
          await logActivity(db, me.username, 'device_release', key + (seg[3] ? ' (one device)' : ' (all devices)'));
          return J({ ok: true });
        }
      }
      if (seg[2] === 'password' && m === 'POST') {
        needAdmin();
        const pw = String((await body()).password || '');
        if (pw.length < 6) fail(400, 'Password must be at least 6 characters.');
        const h = await makeHash(env, pw);
        await db.batch([
          db.prepare('UPDATE users SET salt=?, hash=?, algo=?, iter=? WHERE key=?').bind(h.salt, h.hash, h.algo, h.iter, key),
          db.prepare('DELETE FROM sessions WHERE user_key = ?').bind(key)
        ]);
        await logActivity(db, me.username, 'password_reset', key);
        return J({ ok: true });
      }
      if (!seg[2] && m === 'PATCH') {
        const b = await body(), self = key === me.key;
        if (!isAdmin && !self) fail(403, 'Administrator access required.');
        let role = target.role;
        if (b.role != null && b.role !== target.role) {
          needAdmin();
          role = b.role === 'admin' ? 'admin' : 'user';
          if (target.role === 'admin' && role !== 'admin' && (await adminCount(db)) <= 1) fail(400, 'At least one administrator must remain.');
          if (self) fail(400, 'You cannot change your own access level.');
        }
        const name = b.name != null ? str(b.name, 80).trim() : target.name, emp = b.empNo != null ? str(b.empNo, 40).trim() : target.emp_no;
        if (!name) fail(400, 'Name cannot be empty.');
        await db.prepare('UPDATE users SET name=?, emp_no=?, role=? WHERE key=?').bind(name, emp, role, key).run();
        if (role !== target.role) { await db.prepare('DELETE FROM sessions WHERE user_key = ?').bind(key).run(); await logActivity(db, me.username, 'user_role', key + ' -> ' + role); }
        const u = await db.prepare('SELECT key, username, name, emp_no, role, created FROM users WHERE key = ?').bind(key).first();
        return J({ user: pub(u) });
      }
      if (!seg[2] && m === 'DELETE') {
        needAdmin();
        if (key === me.key) fail(400, 'You cannot remove your own account.');
        if (target.role === 'admin' && (await adminCount(db)) <= 1) fail(400, 'The last administrator cannot be removed.');
        await db.batch([db.prepare('DELETE FROM users WHERE key = ?').bind(key), db.prepare('DELETE FROM sessions WHERE user_key = ?').bind(key)]);
        await logActivity(db, me.username, 'user_remove', key);
        return J({ ok: true });
      }
      break;
    }

    case 'reports': {
      if (!seg[1] && m === 'GET') {
        const rows = (await db.prepare(`SELECT ${REP_COLS} FROM reports ORDER BY captured_at DESC LIMIT 5000`).all()).results;
        return J({ reports: rows.map(repOut) });
      }
      const id = decodeURIComponent(seg[1] || '');
      if (m === 'GET') {
        const r = await db.prepare(`SELECT ${REP_COLS}, photo FROM reports WHERE id = ?`).bind(id).first();
        if (!r) fail(404, 'Report not found.');
        const o = repOut(r); o.photo = r.photo || null; return J({ report: o });
      }
      if (m === 'PUT') { const now = await putReport(db, me, id, await body()); return J({ ok: true, updatedAt: now }); }
      if (m === 'DELETE') {
        const r = await db.prepare('SELECT created_by FROM reports WHERE id = ?').bind(id).first();
        if (!r) return J({ ok: true });
        if (!isAdmin && keyOf(r.created_by) !== keyOf(me.username)) fail(403, 'You can only delete your own reports.');
        await db.prepare('DELETE FROM reports WHERE id = ?').bind(id).run();
        return J({ ok: true });
      }
      break;
    }

    case 'photos': {
      const ids = (url.searchParams.get('ids') || '').split(',').filter(x => REPORT_ID.test(x)).slice(0, 6);
      if (!ids.length) return J({ photos: {} });
      const rows = (await db.prepare(`SELECT id, photo, photo_rev FROM reports WHERE id IN (${ids.map(() => '?').join(',')})`).bind(...ids).all()).results;
      const out = {}; rows.forEach(r => { if (r.photo) out[r.id] = { photo: r.photo, rev: r.photo_rev }; });
      return J({ photos: out });
    }

    case 'activity': {
      if (m === 'POST') {
        const b = await body(); await logActivity(db, me.username, b.action, b.detail, b.reportId); return J({ ok: true });
      }
      needAdmin();
      let sql = 'SELECT id, at, username, action, detail, report_id FROM activity_log WHERE 1=1'; const args = [];
      const un = url.searchParams.get('username'), since = url.searchParams.get('since');
      if (un) { sql += ' AND username = ?'; args.push(un); }
      if (since) { sql += ' AND at >= ?'; args.push(since); }
      sql += ' ORDER BY at DESC LIMIT ?'; args.push(Math.min(5000, parseInt(url.searchParams.get('limit') || '300', 10) || 300));
      const rows = (await db.prepare(sql).bind(...args).all()).results;
      return J({ logs: rows.map(r => ({ id: r.id, at: r.at, username: r.username, action: r.action, detail: r.detail, reportId: r.report_id })) });
    }

    case 'admin': {
      needAdmin();
      if (seg[1] === 'users' && m === 'GET') {
        const rows = (await db.prepare('SELECT key, username, name, emp_no, role, salt, hash, algo, iter, created FROM users').all()).results;
        return J({ users: rows.map(r => Object.assign(pub(r), { salt: r.salt, hash: r.hash, algo: r.algo, iter: r.iter })) });
      }
      if (seg[1] === 'import-user' && m === 'POST') {
        const b = await body(), key = keyOf(b.key || b.username);
        if (!key || !b.salt || !b.hash) fail(400, 'Bad user record.');
        const algo = b.algo === 'pbkdf2' ? 'pbkdf2' : 'legacy';
        const sql = b.ignoreExisting ? 'INSERT OR IGNORE' : 'INSERT OR REPLACE';
        await db.prepare(`${sql} INTO users (key,username,name,emp_no,role,salt,hash,algo,iter,created) VALUES (?,?,?,?,?,?,?,?,?,?)`)
          .bind(key, str(b.username || key, 30), str(b.name || key, 80), str(b.empNo || b.emp_no, 40), b.role === 'admin' ? 'admin' : 'user',
            str(b.salt, 64), str(b.hash, 128), algo, parseInt(b.iter, 10) || 10000, str(b.created || nowIso(), 40)).run();
        return J({ ok: true });
      }
      if (seg[1] === 'import-activity' && m === 'POST') {
        const items = ((await body()).items || []).slice(0, 300);
        if (items.length) await db.batch(items.map(a => db.prepare('INSERT INTO activity_log (at, username, action, detail, report_id) VALUES (?,?,?,?,?)')
          .bind(str(a.at || nowIso(), 40), str(a.username, 60), str(a.action, 40), str(a.detail, 300), a.reportId || a.report_id || null)));
        return J({ ok: true, n: items.length });
      }
      if (seg[1] === 'wipe' && m === 'POST') {
        // keeps the acting administrator (and their session) so a restore can never lock everyone out
        await db.batch([db.prepare('DELETE FROM reports'), db.prepare('DELETE FROM activity_log'), db.prepare('DELETE FROM login_attempts'),
          db.prepare('DELETE FROM users WHERE key <> ?').bind(me.key), db.prepare('DELETE FROM sessions WHERE user_key <> ?').bind(me.key)]);
        return J({ ok: true });
      }
      break;
    }
  }
  return fail(404, 'Unknown API route.');
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (!url.pathname.startsWith('/api/')) return env.ASSETS ? env.ASSETS.fetch(request) : new Response('Not found', { status: 404 });
    try {
      const res = await route(request, env, url);
      if (request.method !== 'GET' && res.status < 400 && /^\/api\/(users|reports|admin)/.test(url.pathname) && env.PORTAL_DB)
        await env.PORTAL_DB.prepare("UPDATE meta SET v = v + 1 WHERE k = 'rev'").run();
      return res;
    }
    catch (e) {
      if (e instanceof HttpError) return J({ error: e.message }, e.status);
      console.error(e);
      return J({ error: 'Server error: ' + (e && e.message || 'unknown') }, 500);
    }
  }
};
