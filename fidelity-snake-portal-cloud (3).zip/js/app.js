/* Fidelity Services Group - Eswatini (Bigbend) Snake Catchers Portal - application logic */
const $ = s => document.querySelector(s);
const $$ = s => Array.from(document.querySelectorAll(s));
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const ICONS = {
  home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h5v-6h4v6h5V10"/>',
  snake: '<path d="M6 20c5 2 10-1 5-5s3-6 5-8c1.5-2 0-4-3-4"/><circle cx="14" cy="4" r=".6"/><path d="M6 20c-2 0-3-2-1-3"/>',
  camera: '<path d="M3 8h4l2-3h6l2 3h4v12H3z"/><circle cx="12" cy="13" r="4"/>',
  sprout: '<path d="M12 21v-9"/><path d="M12 12C12 8 9 6 5 6c0 4 3 6 7 6z"/><path d="M12 14c0-3 2-5 6-5 0 3-2 5-6 5z"/>',
  pin: '<path d="M12 21s-7-6.5-7-12a7 7 0 0114 0c0 5.500-7 12-7 12z"/><circle cx="12" cy="9" r="2.500"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-8M22 20H2"/>',
  users: '<circle cx="9" cy="8" r="3.500"/><path d="M2 20c0-4 3-6 7-6s7 2 7 6"/><circle cx="17" cy="9" r="2.500"/><path d="M17 14c3 0 5 2 5 5"/>',
  help: '<circle cx="12" cy="12" r="10"/><path d="M9.500 9a2.500 2.500 0 015 .5c0 2-2.500 2-2.500 4"/><path d="M12 17.500v.1"/>',
  dl: '<path d="M12 3v12M7 10l5 5 5-5M4 20h16"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.900 4.900l2.100 2.100M17 17l2.100 2.100M4.900 19.100L7 17M17 7l2.100-2.100"/>',
  lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 018 0v4"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
  logout: '<path d="M9 21H5V3h4M16 17l5-5-5-5M21 12H9"/>',
  shield: '<path d="M12 3l8 3v6c0 5-4 8-8 9-4-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
  doc: '<path d="M6 2h9l5 5v15H6z"/><path d="M14 2v6h6M9 13h8M9 17h8"/>',
  image: '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 17l-5-5-9 8"/>',
  save: '<path d="M4 4h13l3 3v13H4z"/><path d="M8 4v6h8V4M8 20v-6h8v6"/>',
  share: '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.600 10.600l6.800-4.200M8.600 13.400l6.800 4.200"/>',
  check: '<path d="M5 12l5 5 9-10"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  chevron: '<path d="M6 9l6 6 6-6"/>',
  globe: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2c3 3 3 17 0 20M12 2c-3 3-3 17 0 20"/>',
  key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16 7l3 3"/>'
};
const ico = n => `<svg class="ico" viewBox="0 0 24 24" aria-hidden="true">${ICONS[n] || ''}</svg>`;
function paintIcons(root) { (root || document).querySelectorAll('i[data-ico]').forEach(i => { i.outerHTML = ico(i.dataset.ico); }); }

let ME = null, REPORTS = [], photoData = '', maps = {}, gpsCap = null, gpsRel = null, weatherData = null;

/* ---------- helpers ---------- */
function toast(msg, err) {
  const t = $('#toast'); t.textContent = msg; t.className = err ? 'err' : ''; t.classList.remove('hidden');
  clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.add('hidden'), 3800);
}
const pad = n => String(n).padStart(2, '0');
function fmtDate(iso, withTime) {
  if (!iso) return '';
  const d = new Date(iso); if (isNaN(d)) return '';
  const s = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  return withTime ? `${s} ${pad(d.getHours())}:${pad(d.getMinutes())}` : s;
}
function localInput(d) { d = d || new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`; }
const mapsLink = r => (r.lat != null && r.lng != null) ? `https://maps.google.com/?q=${r.lat},${r.lng}` : '';
const locLabel = r => r.site || r.releaseLoc || (r.lat != null ? `${(+r.lat).toFixed(4)}, ${(+r.lng).toFixed(4)}` : '-');
const isAdmin = () => ME && ME.role === 'admin';
const newId = () => 'R' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

function modal(title, html, onMount) {
  const root = $('#modalRoot');
  root.innerHTML = `<div class="modal-bg"><div class="modal" role="dialog" aria-modal="true" aria-label="${esc(title)}"><header><span>${esc(title)}</span><button aria-label="Close" id="mClose">&times;</button></header><div class="body">${html}</div></div></div>`;
  const close = () => { root.innerHTML = ''; };
  root.querySelector('#mClose').onclick = close;
  root.querySelector('.modal-bg').addEventListener('mousedown', e => { if (e.target.classList.contains('modal-bg')) close(); });
  paintIcons(root);
  if (onMount) onMount(root, close);
  return close;
}

/* ---------- navigation ---------- */
const TITLES = { dashboard: 'Dashboard', map: 'Live Map', reports: 'All Reports', users: 'User Management', settings: 'Settings', help: 'Help & Support' };
function showView(v) {
  if ((v === 'users') && !isAdmin()) v = 'dashboard';
  $$('.view').forEach(x => x.classList.toggle('active', x.id === 'v-' + v));
  $$('.side .nav[data-view]').forEach(b => b.classList.toggle('active', b.dataset.view === v));
  $('#navRegister').classList.remove('active');
  $('#pageTitle').textContent = TITLES[v] || 'Dashboard';
  if (v === 'map') { initBigMap(); setTimeout(() => { maps.big.invalidateSize(); fitMap(maps.big); }, 60); }
  if (v === 'dashboard') setTimeout(() => maps.small && maps.small.invalidateSize(), 60);
  if (v === 'users') { renderUsers(); fillFootprintUsers(); renderFootprint(); }
  if (v === 'settings') renderSettings();
  window.scrollTo({ top: 0 });
}

/* ---------- maps ---------- */
function makeMap(el) {
  const m = L.map(el, { zoomControl: true }).setView([-26.33, 31.19], 11);
  const sat = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', { maxZoom: 19, attribution: 'Tiles &copy; Esri' });
  const osm = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; OpenStreetMap contributors' });
  sat.addTo(m); L.control.layers({ Satellite: sat, Streets: osm }, null, { position: 'bottomleft' }).addTo(m);
  const lg = L.control({ position: 'topright' });
  lg.onAdd = () => { const d = L.DomUtil.create('div', 'legend'); d.innerHTML = '<div><span class="dot" style="background:#e53935"></span>Captured</div><div><span class="dot" style="background:#2e9e3c"></span>Released</div>'; return d; };
  lg.addTo(m);
  m._grp = L.layerGroup().addTo(m);
  return m;
}
function initBigMap() { if (!maps.big) { maps.big = makeMap('bigmap'); drawMarkers(maps.big); } }
function drawMarkers(m) {
  m._grp.clearLayers();
  REPORTS.filter(r => r.lat != null && r.lng != null && !isNaN(r.lat)).forEach(r => {
    const cls = r.status === 'Released' ? 'rel' : 'cap';
    const icon = L.divIcon({ className: '', html: `<div class="pin ${cls}"></div>`, iconSize: [26, 26], iconAnchor: [8, 26], popupAnchor: [5, -26] });
    const when = fmtDate(r.status === 'Released' && r.releasedAt ? r.releasedAt : r.capturedAt);
    L.marker([r.lat, r.lng], { icon }).addTo(m._grp).bindPopup(
      `<b>${esc(r.status)}: ${when}</b><br>${esc(locLabel(r))}<br><small>${esc(r.catcher)}</small>` +
      (r.photo ? `<br><img src="${r.photo}" style="width:160px;margin-top:6px;border-radius:3px">` : ''));
  });
}
function fitMap(m) {
  const pts = REPORTS.filter(r => r.lat != null && !isNaN(r.lat)).map(r => [r.lat, r.lng]);
  if (pts.length) m.fitBounds(L.latLngBounds(pts).pad(0.25), { maxZoom: 16 });
}

/* ---------- data refresh ---------- */
async function refresh() {
  REPORTS = (await DB.reports()).sort((a, b) => (b.capturedAt || '').localeCompare(a.capturedAt || ''));
  $('#sTotal').textContent = REPORTS.length;
  $('#sCap').textContent = REPORTS.filter(r => r.status !== 'Released').length;
  $('#sRel').textContent = REPORTS.filter(r => r.status === 'Released').length;
  const locs = new Set(REPORTS.filter(r => r.lat != null && !isNaN(r.lat)).map(r => (+r.lat).toFixed(4) + ',' + (+r.lng).toFixed(4)));
  $('#sLoc').textContent = locs.size;
  drawMarkers(maps.small); fitMap(maps.small);
  if (maps.big) drawMarkers(maps.big);
  fillUserFilter();
  renderRows();
}

/* ---------- form ---------- */
function resetForm() {
  $('#fDesc').value = ''; $('#fRel').value = ''; $('#fSite').value = ''; $('#fStatus').value = 'Captured';
  $('#fWhen').value = localInput(); photoData = ''; setPhoto('');
  gpsCap = null; gpsRel = null;
  $('#fLat').value = ''; $('#fLng').value = '';
  $('#fRelLat').value = ''; $('#fRelLng').value = '';
  showGps('cap'); showGps('rel');
}
function showGps(kind) {
  const isCap = kind === 'cap';
  const latEl = isCap ? $('#fLat') : $('#fRelLat');
  const lngEl = isCap ? $('#fLng') : $('#fRelLng');
  const box = isCap ? $('#gpsBoxCap') : $('#gpsBoxRel');
  const gps = isCap ? gpsCap : gpsRel;
  const lat = latEl.value, lng = lngEl.value;
  if (lat !== '' && lng !== '' && !isNaN(+lat) && !isNaN(+lng)) {
    box.className = 'gps-ok';
    box.innerHTML = `${ico('check')}<span>Lat: ${(+lat).toFixed(4)}, Lon: ${(+lng).toFixed(4)}${gps && gps.acc ? ' (&plusmn;' + Math.round(gps.acc) + ' m)' : ''}</span>`;
  } else {
    box.className = 'gps-ok warn';
    box.innerHTML = isCap ? '<span>No capture location yet</span>' : '<span>No release location yet</span>';
  }
}
function getDeviceLocation(kind) {
  if (!navigator.geolocation) return toast('GPS is not available on this device. Type the coordinates instead.', true);
  const isCap = kind === 'cap';
  const btn = isCap ? $('#btnGpsCap') : $('#btnGpsRel');
  const label = isCap ? 'Capture Location' : 'Release Location (GPS)';
  btn.disabled = true;
  btn.innerHTML = `${ico('pin')} Locating…`;
  navigator.geolocation.getCurrentPosition(p => {
    const acc = p.coords.accuracy;
    if (isCap) {
      gpsCap = { acc };
      $('#fLat').value = p.coords.latitude.toFixed(6);
      $('#fLng').value = p.coords.longitude.toFixed(6);
      showGps('cap');
    } else {
      gpsRel = { acc };
      $('#fRelLat').value = p.coords.latitude.toFixed(6);
      $('#fRelLng').value = p.coords.longitude.toFixed(6);
      showGps('rel');
    }
    btn.disabled = false;
    btn.innerHTML = `${ico('pin')}${label}`;
  }, err => {
    btn.disabled = false;
    btn.innerHTML = `${ico('pin')}${label}`;
    toast(err.code === 1
      ? 'Location permission denied. Allow location access or type the coordinates.'
      : 'Could not get a GPS fix. Try outdoors or type the coordinates.', true);
  }, { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 });
}
function setPhoto(data) {
  const t = $('#thumb'), s = $('#photoStatus');
  if (data) { t.innerHTML = `<img src="${data}" alt="Snake photo"><span style="position:absolute;right:4px;bottom:4px;background:#2e9e3c;color:#fff;border-radius:50%;width:22px;height:22px;display:flex;align-items:center;justify-content:center">${ico('check')}</span>`;
    s.style.opacity = 1; s.innerHTML = `${ico('check')}<span>Photo selected<br>(1 file)</span>`; }
  else { t.textContent = 'No photo'; s.style.opacity = .55; s.innerHTML = '<span>No photo selected</span>'; }
}
function compress(file, max = 1024, q = 0.72) {
  return new Promise((res, rej) => {
    const fr = new FileReader();
    fr.onerror = rej;
    fr.onload = () => {
      const img = new Image();
      img.onerror = () => rej(new Error('Could not read that image.'));
      img.onload = () => {
        const k = Math.min(1, max / Math.max(img.width, img.height));
        const c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        res(c.toDataURL('image/jpeg', q));
      };
      img.src = fr.result;
    };
    fr.readAsDataURL(file);
  });
}
async function onPhoto(e) {
  const f = e.target.files[0]; e.target.value = ''; if (!f) return;
  try { photoData = await compress(f); setPhoto(photoData); } catch (er) { toast(er.message, true); }
}
function formData() {
  const lat = $('#fLat').value, lng = $('#fLng').value;
  const rLat = $('#fRelLat').value, rLng = $('#fRelLng').value;
  return {
    catcher: $('#fName').value.trim(), empNo: $('#fEmp').value.trim(),
    lat: lat !== '' && !isNaN(+lat) ? +lat : null, lng: lng !== '' && !isNaN(+lng) ? +lng : null,
    releaseLat: rLat !== '' && !isNaN(+rLat) ? +rLat : null,
    releaseLng: rLng !== '' && !isNaN(+rLng) ? +rLng : null,
    site: $('#fSite').value.trim(), releaseLoc: $('#fRel').value.trim(), description: $('#fDesc').value.trim(),
    status: $('#fStatus').value, capturedAt: $('#fWhen').value ? new Date($('#fWhen').value).toISOString() : new Date().toISOString(),
    photo: photoData
  };
}
async function saveReport() {
  const d = formData();
  if (!d.catcher || !d.empNo || !d.description) return toast('Fill in the catcher name, employee number and description.', true);
  if (d.status === 'Released' && !d.releaseLoc && d.releaseLat == null)
    return toast('Enter the release location name or capture release GPS for a released snake.', true);
  if (d.lat == null && !confirm('No capture GPS location was set, so this report may not appear on the map. Save anyway?')) return;
  const r = Object.assign({ id: newId(), createdBy: ME.username, createdAt: new Date().toISOString() }, d);
  if (r.status === 'Released') r.releasedAt = new Date().toISOString();
  try {
    await DB.saveReport(r);
    if (typeof Realtime !== 'undefined') Realtime.notifyReportSave(r);
    if (DB.logActivity) await DB.logActivity(ME.username, 'report_save', (r.status || '') + ' · ' + (r.site || r.description || '').slice(0, 80), r.id);
    await refresh(); resetForm(); toast('Report saved.');
  } catch (e) { toast('Could not save: ' + (e && e.message || 'storage is full. Download a backup and clear space.'), true); }
}

/* ---------- sharing (photo included as attachment where supported) ---------- */
function shareText(r) {
  const lines = ['*Fidelity Services Group - Eswatini (Bigbend) - Snake Report*', `Status: ${r.status}`, `Catcher: ${r.catcher} (${r.empNo})`, `Date: ${fmtDate(r.capturedAt, true)}`];
  if (r.site) lines.push('Site: ' + r.site);
  if (r.lat != null) lines.push(`GPS: ${(+r.lat).toFixed(5)}, ${(+r.lng).toFixed(5)}`, 'Map: ' + mapsLink(r));
  if (r.releaseLoc) lines.push('Release location: ' + r.releaseLoc);
  if (r.releaseLat != null && r.releaseLng != null)
    lines.push(`Release GPS: ${(+r.releaseLat).toFixed(5)}, ${(+r.releaseLng).toFixed(5)}`);
  lines.push('Description: ' + r.description);
  return lines.join('\n');
}
async function photoFile(r, name) {
  if (!r || !r.photo) return null;
  try {
    const blob = await (await fetch(r.photo)).blob();
    return new File([blob], name || 'snake-photo.jpg', { type: blob.type || 'image/jpeg' });
  } catch (e) { return null; }
}
async function reportPackZip(r) {
  if (typeof JSZip === 'undefined') throw new Error('ZIP library not loaded.');
  const zip = new JSZip();
  zip.file('report.txt', shareText(r).replace(/\*/g, ''));
  const img = await photoFile(r, 'snake-photo.jpg');
  if (img) zip.file('snake-photo.jpg', img);
  return zip.generateAsync({ type: 'blob' });
}
async function doShare(kind, r) {
  const text = shareText(r);
  const plain = text.replace(/\*/g, '');

  if (kind === 'wa') {
    const file = await photoFile(r);
    if (file && navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
      try {
        await navigator.share({ title: 'Snake report', text: plain, files: [file] });
        return;
      } catch (e) { if (e && e.name === 'AbortError') return; }
    }
    window.open('https://wa.me/?text=' + encodeURIComponent(text), '_blank', 'noopener');
    if (r.photo) toast('Photo could not be attached via WhatsApp Web. Use “Share via device” or “Download pack” to include the image.');
    return;
  }

  if (kind === 'mail') {
    if (r.photo) {
      try {
        const pack = await reportPackZip(r);
        download(pack, `Snake_Report_${(r.id || 'pack').replace(/[^\w-]/g, '_')}.zip`);
        toast('Downloaded ZIP with photo. Attach it to your email.');
      } catch (e) { /* continue to mailto */ }
    }
    location.href = 'mailto:?subject=' + encodeURIComponent('Snake report - ' + (locLabel(r))) + '&body=' + encodeURIComponent(plain);
    return;
  }

  if (kind === 'copy') {
    try { await navigator.clipboard.writeText(plain); toast('Report text copied.'); }
    catch (e) { prompt('Copy the text:', plain); }
    return;
  }

  if (kind === 'pack') {
    try {
      const pack = await reportPackZip(r);
      download(pack, `Snake_Report_${(r.id || 'pack').replace(/[^\w-]/g, '_')}.zip`);
      toast(r.photo ? 'Report pack downloaded (text + photo).' : 'Report pack downloaded (text only — no photo on this report).');
    } catch (e) { toast('Could not build pack: ' + (e.message || 'error'), true); }
    return;
  }

  if (kind === 'dev') {
    if (!navigator.share) return toast('Device sharing is not supported here. Use WhatsApp, Download pack or Copy.', true);
    const data = { title: 'Snake report', text: plain };
    try {
      const file = await photoFile(r);
      if (file && navigator.canShare && navigator.canShare({ files: [file] })) data.files = [file];
      await navigator.share(data);
    } catch (e) { /* cancelled */ }
  }
}
function shareModal(r) {
  modal('Share report', `<p style="margin-top:0">${esc(locLabel(r))} &middot; ${esc(r.status)}${r.photo ? ' · includes photo' : ''}</p>
    <div style="display:grid;gap:10px">
      <button class="btn green" data-s="wa">WhatsApp${r.photo ? ' (with photo)' : ''}</button>
      <button class="btn blue" data-s="mail">Email${r.photo ? ' + download photo pack' : ''}</button>
      <button class="btn orange" data-s="dev">Share via device...${r.photo ? ' (with photo)' : ''}</button>
      <button class="btn grey" data-s="pack">Download pack (text${r.photo ? ' + photo' : ''})</button>
      <button class="btn grey" data-s="copy">Copy text</button>
    </div>`,
    root => root.querySelectorAll('[data-s]').forEach(b => b.onclick = () => doShare(b.dataset.s, r)));
}

/* ---------- reports table ---------- */
function periodStart(period) {
  const now = new Date();
  if (period === 'daily') {
    const d = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    return d;
  }
  if (period === 'weekly') {
    const d = new Date(now);
    const day = d.getDay() || 7; // Mon=1 … Sun=7
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() - (day - 1));
    return d;
  }
  if (period === 'monthly') {
    return new Date(now.getFullYear(), now.getMonth(), 1);
  }
  return null;
}
function fillUserFilter() {
  const sel = $('#qUser');
  if (!sel) return;
  const cur = sel.value;
  const users = [...new Set(REPORTS.map(r => r.createdBy || r.catcher).filter(Boolean))].sort();
  sel.innerHTML = '<option value="">All users</option>' + users.map(u => `<option value="${esc(u)}">${esc(u)}</option>`).join('');
  if (cur && users.includes(cur)) sel.value = cur;
}
function renderRows() {
  const q = ($('#qSearch') && $('#qSearch').value || '').trim().toLowerCase();
  const st = $('#qStatus') ? $('#qStatus').value : '';
  const period = $('#qPeriod') ? $('#qPeriod').value : '';
  const user = $('#qUser') ? $('#qUser').value : '';
  const start = periodStart(period);
  const list = REPORTS.filter(r => {
    if (st && r.status !== st) return false;
    if (user && (r.createdBy || r.catcher) !== user) return false;
    if (start) {
      const t = new Date(r.capturedAt || r.createdAt || 0);
      if (isNaN(t) || t < start) return false;
    }
    if (q && ![r.catcher, r.description, r.site, r.releaseLoc, r.empNo, r.createdBy].join(' ').toLowerCase().includes(q)) return false;
    return true;
  });
  if ($('#qCount')) $('#qCount').textContent = `${list.length} of ${REPORTS.length}`;
  if (!$('#rows')) return;
  $('#rows').innerHTML = list.length ? list.map(r => `<tr>
    <td>${r.photo ? `<img class="t" src="${r.photo}" alt="">` : '-'}</td>
    <td>${fmtDate(r.capturedAt, true)}</td><td>${esc(r.catcher)}<br><small>${esc(r.empNo)}</small></td>
    <td>${esc(locLabel(r))}${r.releaseLoc && r.status === 'Released' ? `<br><small>Released: ${esc(r.releaseLoc)}</small>` : ''}</td>
    <td><span class="badge ${r.status === 'Released' ? 'rel' : 'cap'}">${esc(r.status)}</span></td>
    <td style="max-width:260px">${esc(r.description.length > 110 ? r.description.slice(0, 110) + '...' : r.description)}</td>
    <td style="white-space:nowrap"><button class="btn blue sm" data-a="view" data-id="${r.id}">View</button>
      ${r.status !== 'Released' ? `<button class="btn green sm" data-a="rel" data-id="${r.id}">Mark released</button>` : ''}
      <button class="btn orange sm" data-a="share" data-id="${r.id}">Share</button>
      ${(isAdmin() || r.createdBy === ME.username) ? `<button class="btn red sm" data-a="del" data-id="${r.id}">Delete</button>` : ''}</td></tr>`).join('')
    : `<tr><td colspan="7" class="empty">No reports match the current filters. Adjust filters or register a capture.</td></tr>`;
}
async function rowAction(e) {
  const b = e.target.closest('button[data-a]'); if (!b) return;
  const r = REPORTS.find(x => x.id === b.dataset.id); if (!r) return;
  if (b.dataset.a === 'view') {
    const relGps = (r.releaseLat != null && r.releaseLng != null)
      ? `<a href="https://maps.google.com/?q=${r.releaseLat},${r.releaseLng}" target="_blank" rel="noopener">${(+r.releaseLat).toFixed(5)}, ${(+r.releaseLng).toFixed(5)}</a>`
      : '-';
    modal('Snake report', `${r.photo ? `<img class="big" src="${r.photo}" alt="">` : ''}<div class="kv">
      <b>Status</b><span>${esc(r.status)}</span><b>Catcher</b><span>${esc(r.catcher)} (${esc(r.empNo)})</span>
      <b>Captured</b><span>${fmtDate(r.capturedAt, true)}</span><b>Site</b><span>${esc(r.site || '-')}</span>
      <b>Capture GPS</b><span>${r.lat != null ? `<a href="${mapsLink(r)}" target="_blank" rel="noopener">${(+r.lat).toFixed(5)}, ${(+r.lng).toFixed(5)}</a>` : '-'}</span>
      <b>Release location</b><span>${esc(r.releaseLoc || '-')}</span>
      <b>Release GPS</b><span>${relGps}</span>
      <b>Released</b><span>${fmtDate(r.releasedAt, true) || '-'}</span>
      <b>Description</b><span>${esc(r.description)}</span><b>Logged by</b><span>${esc(r.createdBy || '')}</span></div>`);
  } else if (b.dataset.a === 'share') shareModal(r);
  else if (b.dataset.a === 'del') {
    if (!confirm('Delete this report permanently?')) return;
    await DB.deleteReport(r.id);
    if (typeof Realtime !== 'undefined') Realtime.notifyReportDelete(r.id);
    if (DB.logActivity) await DB.logActivity(ME.username, 'report_delete', r.catcher || r.id, r.id);
    await refresh(); toast('Report deleted.');
  } else if (b.dataset.a === 'rel') {
    modal('Mark as released', `
      <label for="rl">Release location name</label>
      <input type="text" id="rl" value="${esc(r.releaseLoc || '')}" placeholder="e.g. Mhlosinga Reserve">
      <label style="margin-top:10px">Release GPS coordinates</label>
      <button class="btn green" type="button" id="relGpsBtn" style="width:100%;margin-bottom:8px">${ico('pin')}Get Release Location</button>
      <div class="gps-ok warn" id="relGpsBox"><span>No release GPS yet</span></div>
      <div class="latlng" style="margin-top:6px">
        <input type="number" step="any" id="rlLat" placeholder="Release Lat" value="${r.releaseLat != null ? r.releaseLat : ''}">
        <input type="number" step="any" id="rlLng" placeholder="Release Lon" value="${r.releaseLng != null ? r.releaseLng : ''}">
      </div>
      <label for="rw" style="margin-top:10px">Date &amp; time released</label>
      <input type="datetime-local" id="rw" value="${localInput()}" style="width:100%;border:1px solid #9fb0a4;border-radius:3px;padding:7px">
      <div style="margin-top:14px"><button class="btn green" id="rok">Save release</button></div>`, (root, close) => {
      const box = root.querySelector('#relGpsBox');
      const updateBox = () => {
        const la = root.querySelector('#rlLat').value, ln = root.querySelector('#rlLng').value;
        if (la !== '' && ln !== '' && !isNaN(+la) && !isNaN(+ln)) {
          box.className = 'gps-ok';
          box.innerHTML = `${ico('check')}<span>Lat: ${(+la).toFixed(4)}, Lon: ${(+ln).toFixed(4)}</span>`;
        } else {
          box.className = 'gps-ok warn';
          box.innerHTML = '<span>No release GPS yet</span>';
        }
      };
      updateBox();
      root.querySelector('#rlLat').oninput = root.querySelector('#rlLng').oninput = updateBox;
      root.querySelector('#relGpsBtn').onclick = () => {
        if (!navigator.geolocation) return toast('GPS not available. Type coordinates.', true);
        const btn = root.querySelector('#relGpsBtn');
        btn.disabled = true; btn.textContent = 'Locating…';
        navigator.geolocation.getCurrentPosition(p => {
          root.querySelector('#rlLat').value = p.coords.latitude.toFixed(6);
          root.querySelector('#rlLng').value = p.coords.longitude.toFixed(6);
          updateBox();
          btn.disabled = false;
          btn.innerHTML = `${ico('pin')}Get Release Location`;
          paintIcons(root);
        }, () => {
          btn.disabled = false;
          btn.innerHTML = `${ico('pin')}Get Release Location`;
          paintIcons(root);
          toast('Could not get GPS. Try outdoors or type coordinates.', true);
        }, { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 });
      };
      root.querySelector('#rok').onclick = async () => {
        const loc = root.querySelector('#rl').value.trim();
        const la = root.querySelector('#rlLat').value, ln = root.querySelector('#rlLng').value;
        if (!loc && (la === '' || ln === '')) return toast('Enter a release location name or GPS coordinates.', true);
        r.releaseLoc = loc || r.releaseLoc || '';
        if (la !== '' && ln !== '' && !isNaN(+la) && !isNaN(+ln)) {
          r.releaseLat = +la; r.releaseLng = +ln;
        }
        r.status = 'Released';
        r.releasedAt = new Date(root.querySelector('#rw').value || Date.now()).toISOString();
        await DB.saveReport(r);
        if (typeof Realtime !== 'undefined') Realtime.notifyReportSave(r);
        if (DB.logActivity) await DB.logActivity(ME.username, 'report_release', r.releaseLoc || '', r.id);
        close(); await refresh(); toast('Marked as released.');
      };
    });
  }
}

/* ---------- users (admin) ---------- */
async function renderUsers() {
  const users = (await DB.allUsers()).sort((a, b) => a.name.localeCompare(b.name));
  $('#urows').innerHTML = users.map(u => {
    const me = u.key === ME.key;
    return `<tr><td>${esc(u.name)}${me ? ' <small>(you)</small>' : ''}</td><td>${esc(u.username)}</td><td>${esc(u.empNo || '-')}</td>
      <td><select data-role="${u.key}" ${me ? 'disabled title="You cannot change your own access level"' : ''}>
        <option value="user" ${u.role === 'user' ? 'selected' : ''}>User</option><option value="admin" ${u.role === 'admin' ? 'selected' : ''}>Admin</option></select></td>
      <td>${u.devices === undefined ? '-' : (u.role === 'admin' ? `${u.devices} <small>(unlimited)</small>` : `${u.devices} / ${u.maxDevices}`)}</td>
      <td style="white-space:nowrap"><button class="btn orange sm" data-u="fp" data-k="${u.username}">Footprint</button>
        ${u.devices === undefined ? '' : `<button class="btn sm" data-u="dev" data-k="${u.key}">Devices</button>`}
        <button class="btn blue sm" data-u="pw" data-k="${u.key}">Reset password</button>
        ${me ? '' : `<button class="btn red sm" data-u="rm" data-k="${u.key}">Remove</button>`}</td></tr>`;
  }).join('');
}
async function userAction(e) {
  const sel = e.target.closest('select[data-role]');
  if (sel) {
    try { await DB.updateUser(sel.dataset.role, { role: sel.value }); toast('Access level updated.'); }
    catch (er) { toast(er.message, true); } return renderUsers();
  }
  const b = e.target.closest('button[data-u]'); if (!b) return;
  const k = b.dataset.k;
  if (b.dataset.u === 'fp') {
    return showUserFootprint(k);
  }
  if (b.dataset.u === 'dev') return showDevices(k);
  if (b.dataset.u === 'rm') {
    if (!confirm('Remove this user? Their reports stay in the system.')) return;
    try {
      await DB.removeUser(k);
      if (typeof Realtime !== 'undefined') Realtime.notifyUsersChanged();
      if (DB.logActivity) await DB.logActivity(ME.username, 'user_remove', k);
      toast('User removed.');
    } catch (er) { toast(er.message, true); } renderUsers(); fillFootprintUsers(); renderFootprint();
  } else {
    modal('Reset password', `<label for="np">New password for <b>${esc(k)}</b> (min 6 characters)</label><input type="text" id="np" autocomplete="off">
      <div style="margin-top:14px"><button class="btn green" id="npok">Set password</button></div>`, (root, close) => {
      root.querySelector('#npok').onclick = async () => {
        try { await DB.setPassword(k, root.querySelector('#np').value); close(); toast('Password updated.'); } catch (er) { toast(er.message, true); }
      };
    });
  }
}
async function showDevices(k) {
  let d; try { d = await DB.userDevices(k); } catch (er) { return toast(er.message, true); }
  const rows = d.devices.map(x => `<tr><td>${esc(x.ua || 'Unknown browser')}</td><td>${esc(new Date(x.lastLogin).toLocaleString())}</td>
    <td><button class="btn red sm" data-dev="${esc(x.id)}">Release</button></td></tr>`).join('');
  modal('Signed-in devices - ' + k, `<p style="margin:0 0 10px;color:var(--muted)">${d.max ? 'Limit: ' + d.max + ' devices. Releasing a device signs it out so another can sign in.' : 'Administrator accounts have no device limit.'}</p>
    ${d.devices.length ? `<div class="tbl-wrap"><table><thead><tr><th>Browser</th><th>Signed in</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>
    <div style="margin-top:12px"><button class="btn red" id="devAll">Release all devices</button></div>` : '<p>No devices are signed in.</p>'}`, (root, close) => {
    root.querySelectorAll('button[data-dev]').forEach(btn => btn.onclick = async () => {
      try { await DB.releaseDevice(k, btn.dataset.dev); close(); toast('Device released.'); renderUsers(); } catch (er) { toast(er.message, true); }
    });
    const all = root.querySelector('#devAll');
    if (all) all.onclick = async () => { try { await DB.releaseDevice(k); close(); toast('All devices released.'); renderUsers(); } catch (er) { toast(er.message, true); } };
  });
}
function addUserModal() {
  modal('Add user', `<div class="form-grid">
    <div><label>Full name</label><input type="text" id="nuName"></div><div><label>Employee No.</label><input type="text" id="nuEmp"></div>
    <div><label>Username</label><input type="text" id="nuUser" autocapitalize="none" autocomplete="off"></div>
    <div><label>Access level</label><select id="nuRole"><option value="user">User</option><option value="admin">Admin</option></select></div>
    <div class="full"><label>Password (min 6 characters)</label><input type="text" id="nuPw" autocomplete="off"></div></div>
    <div style="margin-top:14px"><button class="btn green" id="nuok">Create user</button></div>`, (root, close) => {
    root.querySelector('#nuok').onclick = async () => {
      try {
        await DB.createUser({ username: root.querySelector('#nuUser').value, name: root.querySelector('#nuName').value, empNo: root.querySelector('#nuEmp').value,
          password: root.querySelector('#nuPw').value, role: root.querySelector('#nuRole').value });
        if (typeof Realtime !== 'undefined') Realtime.notifyUsersChanged();
        close(); toast('User created.'); renderUsers();
      } catch (er) { toast(er.message, true); }
    };
  });
}

/* ---------- admin user footprint ---------- */
async function renderFootprint() {
  if (!$('#fpRows')) return;
  const user = $('#fpUser') ? $('#fpUser').value : '';
  const period = $('#fpPeriod') ? $('#fpPeriod').value : '';
  const start = periodStart(period);
  let logs = [];
  try {
    logs = await DB.activityLogs({ username: user || undefined, limit: 400 });
  } catch (e) { logs = []; }
  if (start) logs = logs.filter(l => new Date(l.at) >= start);
  // Also list report footprint summary rows for selected user
  if ($('#fpCount')) $('#fpCount').textContent = logs.length + ' events';
  $('#fpRows').innerHTML = logs.length ? logs.map(l => `<tr>
    <td>${fmtDate(l.at, true)}</td>
    <td>${esc(l.username)}</td>
    <td><span class="badge usr">${esc(l.action)}</span></td>
    <td>${esc(l.detail || '-')}</td>
    <td>${l.reportId ? esc(l.reportId) : '-'}</td>
  </tr>`).join('') : `<tr><td colspan="5" class="empty">No activity logged yet.</td></tr>`;
}
async function fillFootprintUsers() {
  if (!$('#fpUser')) return;
  const cur = $('#fpUser').value;
  const users = await DB.allUsers();
  $('#fpUser').innerHTML = '<option value="">All users</option>' +
    users.map(u => `<option value="${esc(u.username)}">${esc(u.name)} (${esc(u.username)})</option>`).join('');
  if (cur) $('#fpUser').value = cur;
}

async function showUserFootprint(username) {
  const fp = await DB.userFootprint(username);
  const reps = fp.reports || [];
  const logs = fp.logs || [];
  modal('Footprint · ' + username, `
    <p style="margin-top:0">${reps.length} reports · ${logs.length} log events</p>
    <h3 style="margin:10px 0 6px;color:var(--green-800)">Recent activity</h3>
    <div class="tbl-wrap"><table><thead><tr><th>When</th><th>Action</th><th>Detail</th></tr></thead>
    <tbody>${logs.slice(0, 40).map(l => `<tr><td>${fmtDate(l.at, true)}</td><td>${esc(l.action)}</td><td>${esc(l.detail || '')}</td></tr>`).join('') || '<tr><td colspan="3" class="empty">No logs</td></tr>'}</tbody></table></div>
    <h3 style="margin:14px 0 6px;color:var(--green-800)">Reports</h3>
    <div class="tbl-wrap"><table><thead><tr><th>Date</th><th>Status</th><th>Site</th><th>Description</th></tr></thead>
    <tbody>${reps.slice(0, 40).map(r => `<tr><td>${fmtDate(r.capturedAt, true)}</td><td>${esc(r.status)}</td><td>${esc(r.site || locLabel(r))}</td><td>${esc((r.description || '').slice(0, 80))}</td></tr>`).join('') || '<tr><td colspan="4" class="empty">No reports</td></tr>'}</tbody></table></div>
  `);
}

/* ---------- settings ---------- */
async function renderSettings() {
  $('#sName').value = ME.name; $('#sEmp').value = ME.empNo || '';
  $('#pwOld').value = $('#pwNew').value = $('#pwNew2').value = '';
  applyTipAlign();
  if (isAdmin()) {
    const rs = await DB.reports(), us = await DB.allUsers();
    const bytes = rs.reduce((a, r) => a + (r.photo ? r.photo.length : 0), 0);
    $('#dbInfo').textContent = `${rs.length} reports, ${us.length} users, about ${(bytes / 1048576).toFixed(1)} MB of photos in blob storage.`;
    const cloud = DB.mode === 'cloud';
    if ($('#btnSqlite')) $('#btnSqlite').classList.toggle('hidden', cloud);
    if ($('#btnMigrate')) $('#btnMigrate').classList.toggle('hidden', !cloud);
    if ($('#dbModeNote')) $('#dbModeNote').innerHTML = cloud
      ? 'Connected to the <b>shared cloud database</b> (Cloudflare D1). Users and reports are the same on every device. Download a JSON backup regularly. If this device was used before the cloud database was connected, use <b>Upload this device\'s data to the cloud</b> once.'
      : 'Live data is stored in an embedded <b>SQLite</b> database in this browser, so it is <b>not shared</b> with other devices. Connect the Cloudflare database (see README) to share accounts and reports.';
    if ($('#storageInfo') && DB.storageInfo) {
      DB.storageInfo().then(s => { $('#storageInfo').textContent = cloud ? s.note : s.note + ' — photos stored outside SQLite so capacity can grow toward multi-GB (browser dependent, often up to ~5 GB+ with persistent permission).'; });
    }
    const lb = localStorage.getItem('fs_lastbackup');
    $('#lastBackup').textContent = lb ? 'Last backup downloaded: ' + fmtDate(lb, true) : 'No backup downloaded yet from this browser.';
  }
}
async function downloadBackup() {
  const data = await DB.exportAll();
  download(new Blob([JSON.stringify(data)], { type: 'application/json' }), `Fidelity_Snake_Portal_Backup_${fmtDate(new Date().toISOString())}.json`);
  localStorage.setItem('fs_lastbackup', new Date().toISOString()); renderSettings();
  toast('JSON backup downloaded.');
}
async function downloadSqlite() {
  try {
    const u8 = await DB.exportSqlite();
    download(new Blob([u8], { type: 'application/x-sqlite3' }), `Fidelity_Snake_Portal_${fmtDate(new Date().toISOString())}.sqlite`);
    localStorage.setItem('fs_lastbackup', new Date().toISOString()); renderSettings();
    toast('SQLite database downloaded.');
  } catch (e) { toast('Could not export SQLite: ' + (e.message || 'error'), true); }
}
async function restoreBackup(e) {
  const f = e.target.files[0]; e.target.value = ''; if (!f) return;
  const name = (f.name || '').toLowerCase();
  if (name.endsWith('.sqlite') || name.endsWith('.db') || name.endsWith('.sqlite3')) {
    try {
      const buf = await f.arrayBuffer();
      modal('Restore SQLite database', `<p style="margin-top:0">This replaces the entire live database with <b>${esc(f.name)}</b>.</p>
        <div style="display:grid;gap:10px"><button class="btn red" id="rr">Replace database</button></div>`, (root, close) => {
        root.querySelector('#rr').onclick = async () => {
          if (!confirm('Replace all current users and reports with this SQLite file?')) return;
          try {
            await DB.importSqlite(buf); close();
            toast('SQLite restored. Signing you out so changes apply.');
            setTimeout(() => { DB.logout(); location.replace('login.html'); }, 1500);
          } catch (er) { toast(er.message, true); }
        };
      });
    } catch (er) { toast('Could not read SQLite file.', true); }
    return;
  }
  let data; try { data = JSON.parse(await f.text()); } catch (er) { return toast('That file is not valid JSON or SQLite.', true); }
  modal('Restore backup', `<p style="margin-top:0">Backup contains <b>${(data.reports || []).length}</b> reports and <b>${(data.users || []).length}</b> users.</p>
    <div style="display:grid;gap:10px"><button class="btn green" id="rm">Merge (keep current data, add what is missing)</button>
    <button class="btn red" id="rr">Replace everything with this backup</button></div>`, (root, close) => {
    const go = async rep => {
      if (rep && !confirm('This erases all current users and reports first. Continue?')) return;
      try { await DB.importAll(data, rep); close(); toast('Backup restored. Signing you out so changes apply.'); setTimeout(() => { DB.logout(); location.replace('login.html'); }, 1500); }
      catch (er) { toast(er.message, true); }
    };
    root.querySelector('#rm').onclick = () => go(false); root.querySelector('#rr').onclick = () => go(true);
  });
}
async function saveProfile() {
  const name = $('#sName').value.trim(); if (!name) return toast('Name cannot be empty.', true);
  ME = await DB.updateUser(ME.key, { name, empNo: $('#sEmp').value.trim() });
  $('#who').textContent = `${ME.name} (${isAdmin() ? 'Admin' : 'User'})`;
  if (DB.logActivity) DB.logActivity(ME.username, 'login', 'Session started on this device').catch(() => {}); fillCatcher(); toast('Profile saved.');
}
async function changePw() {
  const o = $('#pwOld').value, n = $('#pwNew').value, n2 = $('#pwNew2').value;
  if (n !== n2) return toast('The new passwords do not match.', true);
  try {
    await DB.changePassword(ME.key, o, n); ME = await DB.currentUser(); renderSettings(); toast('Password changed.');
  } catch (er) { toast(er.message, true); }
}
function fillCatcher() { $('#fName').value = ME.name; $('#fEmp').value = ME.empNo || ''; }

/* ---------- weather + tips ---------- */
const WMO = {
  0: 'Clear sky', 1: 'Mainly clear', 2: 'Partly cloudy', 3: 'Overcast',
  45: 'Fog', 48: 'Depositing rime fog',
  51: 'Light drizzle', 53: 'Drizzle', 55: 'Dense drizzle',
  61: 'Slight rain', 63: 'Rain', 65: 'Heavy rain',
  71: 'Slight snow', 73: 'Snow', 75: 'Heavy snow',
  80: 'Rain showers', 81: 'Rain showers', 82: 'Violent rain showers',
  95: 'Thunderstorm', 96: 'Thunderstorm with hail', 99: 'Thunderstorm with heavy hail'
};

/* Southern Africa / Eswatini-oriented snake safety + weather training tips */
const DAY_TIPS_WEATHER = {
  hot: [
    'Hot day: drink water every 20–30 minutes. Snakes seek cool shade under vehicles, tanks and buildings — check before you reach in.',
    'High heat: snakes are more active at dusk. Plan releases earlier and keep the public back from the work area.',
    'Hot & dry: wear closed shoes and long trousers. Avoid kneeling in long grass without checking first.'
  ],
  warm: [
    'Warm conditions: peak activity for many species. Approach slowly and never corner a snake against a wall.',
    'Good capture weather: keep your kit ready (hooks, tubes, bags). Confirm GPS before you leave the site.'
  ],
  cool: [
    'Cool weather: snakes may bask on warm paths and rocks. Watch your step on paved edges and rubble.',
    'Cooler air: snakes move slower but still bite if handled. Use tools — never bare hands.'
  ],
  cold: [
    'Cold conditions: keep yourself warm in layers. Snakes may be in sheltered voids — open lids carefully.',
    'Cold day: reduced snake movement, but do not assume a still snake is dead.'
  ],
  rain: [
    'Rain: reduced visibility and slippery ground. Mark the last seen location and keep bystanders clear.',
    'Wet weather: snakes may enter buildings seeking dry ground. Check door thresholds and garages.'
  ]
};
const NIGHT_TIPS_WEATHER = {
  hot: [
    'Night heat: many snakes hunt after dark. Use a bright torch and never walk through long grass unlit.',
    'Warm night: check under outdoor lights where prey gathers — snakes follow.'
  ],
  warm: [
    'Night shift: always work in pairs when possible. Announce your position to the control room before approach.',
    'After dark: use red-filter light if available to reduce startling the snake and preserve your night vision.'
  ],
  cool: [
    'Cool night: snakes may rest on warm tarmac. Drive and walk carefully near estates and reserves.',
    'Night cool-down: still treat every snake as venomous until identified by a trained catcher.'
  ],
  cold: [
    'Cold night: limited activity, but garage and plant-room checks still need full PPE discipline.',
    'Cold after dark: keep warm, keep hydrated, and do not rush the capture.'
  ],
  rain: [
    'Rain at night: poor footing and glare. Secure the area first, then search methodically with a torch.',
    'Stormy night: postpone non-urgent captures if lightning is active; protect the public and yourself.'
  ]
};
const SNAKE_LOCAL = [
  'Common in this region: Mozambique spitting cobra — do not face the head; eye exposure needs immediate irrigation and medical care.',
  'Puff adder: thick body, often still until almost stepped on. Use a long hook; never kick or pin with boots only.',
  'Black mamba / green mamba risk in bush edges: keep distance, clear exit path, call for backup if unsure.',
  'Boomslang and vine snakes: arboreal — check shrubs and low trees before moving vegetation.',
  'Rinkhals may feign death: never handle a “dead” snake with bare hands.',
  'Python (non-venomous but powerful): control the head, support the body, two people for large specimens.',
  'House snakes and night adders appear around homes — still identify before handling; night adder is venomous.',
  'If spat in the eyes: flush with clean water for 15+ minutes and seek medical help; do not rub the eyes.',
  'Snake bite training: keep the patient calm and still, immobilise the limb, do not cut or suck the wound, call control room and emergency services.',
  'Bite kit discipline: note time of bite, species if known, and keep the patient from running or eating.',
  'Never pick up a snake by the tail alone — many species can still strike upward.',
  'Release only at approved sites away from homes, schools and busy roads; record release GPS every time.'
];

function isNightHour(d) {
  const h = (d || new Date()).getHours();
  return h < 6 || h >= 18;
}
function weatherBucket(temp, code) {
  if ([61, 63, 65, 80, 81, 82, 95, 96, 99].includes(code)) return 'rain';
  if (temp >= 30) return 'hot';
  if (temp >= 22) return 'warm';
  if (temp <= 12) return 'cold';
  return 'cool';
}
function buildTipPool() {
  const night = isNightHour();
  const sets = night ? NIGHT_TIPS_WEATHER : DAY_TIPS_WEATHER;
  let bucket = 'warm';
  if (weatherData) bucket = weatherBucket(weatherData.temp, weatherData.code);
  const weatherTips = sets[bucket] || sets.warm;
  const period = night ? 'Night tip' : 'Day tip';
  const pool = [];
  weatherTips.forEach(t => pool.push({ title: period + ' · Weather', text: t }));
  SNAKE_LOCAL.forEach(t => pool.push({ title: period + ' · Local snakes & training', text: t }));
  return pool;
}

let tipCycleIdx = 0;
let tipCycleTimer = null;

function applyTipAlign(align) {
  align = align || localStorage.getItem('fs_tip_align') || 'bottom-right';
  const pop = $('#tipPopup');
  if (!pop) return;
  pop.classList.remove('tip-align-bottom-right', 'tip-align-bottom-left', 'tip-align-top-right', 'tip-align-top-left');
  pop.classList.add('tip-align-' + align);
  localStorage.setItem('fs_tip_align', align);
  const sel = $('#sTipAlign');
  if (sel) sel.value = align;
}

function showTipPopup(title, text) {
  const pop = $('#tipPopup');
  if (!pop) return;
  $('#tipTitle').textContent = title;
  $('#tipText').textContent = text;
  $('#tipIco').innerHTML = ico('snake');
  applyTipAlign();
  pop.classList.remove('hidden');
}

function cycleTips() {
  const pool = buildTipPool();
  if (!pool.length) return;
  tipCycleIdx = tipCycleIdx % pool.length;
  const item = pool[tipCycleIdx++];
  showTipPopup(item.title, item.text);
}

function startTipCycle() {
  clearInterval(tipCycleTimer);
  cycleTips();
  tipCycleTimer = setInterval(cycleTips, 20000); // every 20 seconds, day and night
}

async function loadWeather(lat, lng) {
  lat = lat != null ? lat : -26.33;
  lng = lng != null ? lng : 31.19;
  try {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m&timezone=auto`;
    const res = await fetch(url);
    if (!res.ok) throw new Error('weather fetch failed');
    const data = await res.json();
    const c = data.current;
    weatherData = {
      temp: Math.round(c.temperature_2m),
      hum: Math.round(c.relative_humidity_2m),
      wind: Math.round(c.wind_speed_10m),
      code: c.weather_code,
      desc: WMO[c.weather_code] || 'Unknown',
      lat, lng
    };
    renderWeather();
    startTipCycle();
  } catch (e) {
    if ($('#wDesc')) $('#wDesc').textContent = 'Weather unavailable (offline or blocked).';
    startTipCycle(); // still cycle snake/training tips
  }
}
function renderWeather() {
  if (!weatherData) return;
  if ($('#wTemp')) $('#wTemp').textContent = weatherData.temp;
  if ($('#wDesc')) $('#wDesc').textContent = weatherData.desc;
  if ($('#wHum')) $('#wHum').textContent = `Humidity ${weatherData.hum}%`;
  if ($('#wWind')) $('#wWind').textContent = `Wind ${weatherData.wind} km/h`;
  if ($('#wTip')) {
    const pool = buildTipPool();
    if (pool[0]) $('#wTip').textContent = pool[0].text;
  }
  if ($('#weatherLoc')) $('#weatherLoc').textContent = `(${weatherData.lat.toFixed(2)}, ${weatherData.lng.toFixed(2)})`;
}
function tickWeatherTile() {
  const d = new Date();
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  if ($('#wCal')) $('#wCal').textContent = `${days[d.getDay()]} ${pad(d.getDate())} ${months[d.getMonth()]} ${d.getFullYear()}`;
  if ($('#wClock')) $('#wClock').textContent = `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  if ($('#wDayNight')) $('#wDayNight').textContent = isNightHour(d) ? 'Night tips active' : 'Day tips active';
}

/* ---------- live session refresh (no page reload needed) ---------- */
let liveRev = null;
async function liveTick() {
  try {
    if (document.hidden) return;                     // no polling while the tab is in the background
    if (DB.mode === 'cloud') {                       // one tiny request; reload data only when something changed
      let rev;
      try { rev = await DB.rev(); } catch (e) { if (e.status === 401) { DB.logout(); return location.replace('login.html'); } throw e; }
      if (rev === liveRev) return;
      liveRev = rev;
    }
    const u = await DB.currentUser();
    if (!u) { DB.logout(); return location.replace('login.html'); }
    ME = u;
    await refresh();
    fillUserFilter();
  } catch (e) { /* keep previous data */ }
}

/* ---------- real-time remote events (WebSocket) ---------- */
async function onRealtimeMessage(msg) {
  if (!msg || !msg.type) return;
  if (msg.type === 'report:save' && msg.report && msg.report.id) {
    const incoming = msg.report;
    const existing = await DB.getReport(incoming.id);
    // Keep local photo if remote omitted a large image
    if (existing && existing.photo && (!incoming.photo || incoming.photoOmitted)) {
      incoming.photo = existing.photo;
      delete incoming.photoOmitted;
    }
    await DB.saveReport(incoming);
    await refresh();
    if (msg.from) toast('Live update: report from ' + msg.from);
    return;
  }
  if (msg.type === 'report:delete' && msg.id) {
    await DB.deleteReport(msg.id);
    await refresh();
    toast('Live update: a report was removed.');
    return;
  }
  if (msg.type === 'sync' && Array.isArray(msg.reports)) {
    for (const r of msg.reports) {
      if (!r || !r.id) continue;
      const existing = await DB.getReport(r.id);
      if (existing && existing.photo && (!r.photo || r.photoOmitted)) {
        r.photo = existing.photo;
        delete r.photoOmitted;
      }
      await DB.saveReport(r);
    }
    await refresh();
    return;
  }
  if (msg.type === 'users:changed') {
    if (typeof renderUsers === 'function' && $('#v-users') && $('#v-users').classList.contains('active')) {
      try { await renderUsers(); } catch (e) { /* ignore */ }
    }
  }
}

/* ---------- init ---------- */
(async function init() {
  try { await DB.detect(); await DB.ensureSeed(); ME = await DB.currentUser(); } catch (e) { ME = null; }
  if (!ME) { DB.logout(); return location.replace('login.html'); }

  $('#brand').innerHTML = brandBar(); $('#sideSnake').innerHTML = BRAND.snake;
  paintIcons();
  $('#who').textContent = `${ME.name} (${isAdmin() ? 'Admin' : 'User'})`;
  $('#crNum').textContent = CONFIG.controlRoom;
  if (!isAdmin()) $$('.admin-only').forEach(e => e.remove()); else $$('.admin-only').forEach(e => e.classList.remove('hidden'));

  maps.small = makeMap('map');
  fillCatcher(); $('#fWhen').value = localInput(); showGps('cap'); showGps('rel');

  // nav
  $$('[data-view]').forEach(b => b.addEventListener('click', () => showView(b.dataset.view)));
  $('#navRegister').onclick = () => { showView('dashboard'); $('#navRegister').classList.add('active'); $$('.side .nav[data-view]').forEach(x => x.classList.remove('active'));
    setTimeout(() => { $('#formCard').scrollIntoView({ behavior: 'smooth', block: 'start' }); $('#fDesc').focus({ preventScroll: true }); }, 80); };
  $('#navReports').onclick = () => $('#subReports').classList.toggle('hidden');
  $('#navExport').onclick = () => { showView('dashboard'); setTimeout(() => $('#exportCard').scrollIntoView({ behavior: 'smooth' }), 80); };
  $('#btnSettings').onclick = () => showView('settings');
  $('#btnLogout').onclick = () => {
    if (typeof Realtime !== 'undefined') Realtime.stop();
    DB.logout();
    location.replace('login.html');
  };

  // form — dual GPS buttons
  $('#btnGpsCap').onclick = () => getDeviceLocation('cap');
  $('#btnGpsRel').onclick = () => getDeviceLocation('rel');
  $('#fLat').oninput = $('#fLng').oninput = () => { gpsCap = null; showGps('cap'); };
  $('#fRelLat').oninput = $('#fRelLng').oninput = () => { gpsRel = null; showGps('rel'); };
  $('#btnUpload').onclick = () => $('#fUpload').click(); $('#btnCam').onclick = () => $('#fCam').click();
  $('#fUpload').onchange = $('#fCam').onchange = onPhoto;
  $('#btnSave').onclick = saveReport;
  $('#btnShare').onclick = e => { e.stopPropagation(); $('#shareMenu').classList.toggle('hidden'); };
  document.addEventListener('click', () => $('#shareMenu').classList.add('hidden'));
  $$('#shareMenu [data-s]').forEach(b => b.onclick = () => {
    const d = formData(); if (!d.description && !d.catcher) return toast('Fill in the report first.', true);
    doShare(b.dataset.s, d);
  });

  // tables + filters
  const refilter = () => renderRows();
  if ($('#qSearch')) $('#qSearch').oninput = refilter;
  if ($('#qStatus')) $('#qStatus').onchange = refilter;
  if ($('#qPeriod')) $('#qPeriod').onchange = refilter;
  if ($('#qUser')) $('#qUser').onchange = refilter;
  $('#rows').addEventListener('click', rowAction);
  $('#urows').addEventListener('click', userAction); $('#urows').addEventListener('change', userAction);
  const au = $('#btnAddUser'); if (au) au.onclick = addUserModal;

  // settings
  $('#btnProfile').onclick = saveProfile; $('#btnPw').onclick = changePw;
  const bb = $('#btnBackup'); if (bb) { bb.onclick = downloadBackup; $('#btnRestore').onclick = () => $('#fRestore').click(); $('#fRestore').onchange = restoreBackup; }
  const bs = $('#btnSqlite'); if (bs) bs.onclick = downloadSqlite;
  const bm = $('#btnMigrate'); if (bm) bm.onclick = async () => {
    if (!confirm('Copy the users and reports saved on THIS device into the shared cloud database? Existing cloud data is kept; only missing items are added.')) return;
    bm.disabled = true; bm.lastChild.textContent = 'Uploading...';
    try { const n = await DB.migrateLocalToCloud(); await refresh(); renderSettings(); toast(`Uploaded ${n.reports} reports and ${n.users} users to the cloud.`); }
    catch (er) { toast(er.message || 'Upload failed.', true); }
    finally { bm.disabled = false; bm.lastChild.textContent = "Upload this device's data to the cloud"; }
  };

  // exports
  $$('[data-exp]').forEach(b => b.onclick = () => runExport(b.dataset.exp));

  // tip popup dismiss + alignment
  const tipClose = $('#tipClose');
  if (tipClose) tipClose.onclick = () => $('#tipPopup').classList.add('hidden');
  applyTipAlign();
  const btnTip = $('#btnTipAlign');
  if (btnTip) btnTip.onclick = () => {
    applyTipAlign($('#sTipAlign').value);
    toast('Tip position saved.');
  };
  if ($('#fpUser')) $('#fpUser').onchange = renderFootprint;
  if ($('#fpPeriod')) $('#fpPeriod').onchange = renderFootprint;

  // footer — live clock with seconds
  const tick = () => {
    const d = new Date();
    const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    $('#clock').innerHTML = `${pad(d.getDate())} ${months[d.getMonth()]} ${d.getFullYear()} &bull; ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  };
  tick(); tickWeatherTile(); setInterval(() => { tick(); tickWeatherTile(); }, 1000);
  const net = () => { const o = $('#online'); o.textContent = navigator.onLine ? 'Online' : 'Offline'; o.classList.toggle('off', !navigator.onLine); };
  addEventListener('online', net); addEventListener('offline', net); net();

  document.body.classList.remove('locked');
  await refresh();
  fillUserFilter();

  // Weather: try device location first, else map default
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      p => loadWeather(p.coords.latitude, p.coords.longitude),
      () => loadWeather(),
      { enableHighAccuracy: false, timeout: 8000, maximumAge: 600000 }
    );
  } else loadWeather();

  // Live data refresh every 45s so session stays current without page reload
  setInterval(liveTick, DB.mode === 'cloud' ? 15000 : 45000);
  if (DB.mode === 'cloud') DB.rev().then(r => { liveRev = r; }).catch(() => {});
  if (DB.mode === 'cloud') {                       // photos arrive in the background - redraw when they do
    let busy = false; DB.onPhotos = async () => { if (busy) return; busy = true; try { await refresh(); } catch (e) { /* ignore */ } busy = false; };
  }

  // Real-time: WebSocket when CONFIG.wsUrl is set
  if (typeof Realtime !== 'undefined') {
    Realtime.start({ onRemoteChange: onRealtimeMessage });
  }
})();
