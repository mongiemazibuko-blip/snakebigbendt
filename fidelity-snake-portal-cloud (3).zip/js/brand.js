/* Inline SVG brand art (swap for real logo files if you have them) */
const BRAND = {
  fidelity: `<img src="assets/fidelity-logo.png" alt="Fidelity - A Member of the Fidelity Security Group" style="height:74px;width:auto;display:block">`,
  shield: `<svg width="92" height="104" viewBox="0 0 92 104" aria-hidden="true"><path d="M46 4 L86 16 V52 C86 78 66 94 46 100 C26 94 6 78 6 52 V16 Z" fill="#14631f" stroke="#e8f1e4" stroke-width="3"/>
    <text x="46" y="38" text-anchor="middle" font-family="Segoe UI,Arial" font-weight="800" font-size="17" fill="#fff">Safety</text>
    <text x="46" y="58" text-anchor="middle" font-family="Segoe UI,Arial" font-weight="800" font-size="17" fill="#fff">First</text>
    <path d="M30 72 L42 83 L64 62" fill="none" stroke="#fff" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  snake: `<svg viewBox="0 0 200 80" width="190" height="76" aria-hidden="true"><path d="M5 62 C35 80 55 30 90 48 C120 62 120 20 150 28 C168 33 175 20 190 16" fill="none" stroke="#3b2f1b" stroke-width="14" stroke-linecap="round"/>
    <path d="M5 62 C35 80 55 30 90 48 C120 62 120 20 150 28 C168 33 175 20 190 16" fill="none" stroke="#c8a24a" stroke-width="6" stroke-dasharray="7 9" stroke-linecap="round"/><circle cx="188" cy="16" r="2.5" fill="#fff"/></svg>`
};
function brandBar() {
  return `<div class="brandbar">${BRAND.fidelity}<div class="divider"></div>
    <div><h1>Fidelity Services Group - Eswatini (Bigbend)</h1><h2>Snake Catchers Portal</h2><div class="tag">Report &nbsp;•&nbsp; Protect &nbsp;•&nbsp; Preserve</div></div>
    <div class="art">${BRAND.snake}${BRAND.shield}</div></div>`;
}
window.BRAND = BRAND;
window.brandBar = brandBar;
