/* Cloud (shared) database client + automatic mode selection.
   - If the Cloudflare D1 backend is connected (/api/health says db:true) every device shares one database.
   - Otherwise the portal falls back to the browser-local SQLite database (DBLocal, defined in db.js).
   window.DB is a thin proxy that forwards to whichever one is active. */
(() => {
  const TOKEN_KEY = 'fs_token';
  const MODE_KEY = 'fs_mode';
  const getTok = () => localStorage.getItem(TOKEN_KEY) || '';
  /* each browser gets a permanent random device id; the server uses it to enforce the 2-device limit for normal users */
  function deviceId() {
    let d = localStorage.getItem('fs_device');
    if (!/^[a-f0-9]{32}$/.test(d || '')) { d = Array.from(crypto.getRandomValues(new Uint8Array(16)), b => b.toString(16).padStart(2, '0')).join(''); localStorage.setItem('fs_device', d); }
    return d;
  }

  async function api(method, path, body) {
    const headers = { 'Accept': 'application/json' };
    const t = getTok(); if (t) headers.Authorization = 'Bearer ' + t;
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    let res;
    try { res = await fetch('/api' + path, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined, cache: 'no-store' }); }
    catch (e) { const er = new Error('Cannot reach the portal server. Check your internet connection and try again.'); er.network = true; throw er; }
    let data = null; try { data = await res.json(); } catch (e) { /* non-JSON */ }
    if (!res.ok) { const er = new Error((data && data.error) || ('Server error (' + res.status + ')')); er.status = res.status; throw er; }
    return data || {};
  }

  /* ---------- photo cache (memory + IndexedDB) so photos download once per device ---------- */
  const mem = new Map();            // id -> { rev, data }
  const pending = new Set();
  let warmP = null, photoTimer = null, queue = [], running = 0;
  const IDB = 'fidelity_cloud_cache';
  function idb() {
    return new Promise((res, rej) => {
      const r = indexedDB.open(IDB, 1);
      r.onupgradeneeded = () => r.result.createObjectStore('photos');
      r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
    });
  }
  function warm() {
    if (!warmP) warmP = (async () => {
      try {
        const d = await idb();
        await new Promise(res => {
          const st = d.transaction('photos', 'readonly').objectStore('photos'), keys = st.getAllKeys(), vals = st.getAll();
          vals.onsuccess = () => { const k = keys.result || [], v = vals.result || []; k.forEach((id, i) => { if (v[i]) mem.set(id, v[i]); }); res(); };
          vals.onerror = () => res();
        });
      } catch (e) { /* cache is optional */ }
    })();
    return warmP;
  }
  async function cachePut(id, rev, data) {
    mem.set(id, { rev, data });
    try { const d = await idb(); d.transaction('photos', 'readwrite').objectStore('photos').put({ rev, data }, id); } catch (e) { /* ignore */ }
  }
  async function cacheDel(id) {
    mem.delete(id);
    try { const d = await idb(); d.transaction('photos', 'readwrite').objectStore('photos').delete(id); } catch (e) { /* ignore */ }
  }
  function notifyPhotos() {
    clearTimeout(photoTimer);
    photoTimer = setTimeout(() => { if (typeof Proxy_.onPhotos === 'function') Proxy_.onPhotos(); }, 500);
  }
  function pump() {
    while (running < 3 && queue.length) {
      const ids = queue.splice(0, 4); running++;
      api('GET', '/photos?ids=' + ids.join(',')).then(async out => {
        for (const id of ids) { const p = out.photos && out.photos[id]; if (p) await cachePut(id, p.rev, p.photo); pending.delete(id); }
        notifyPhotos();
      }).catch(() => { ids.forEach(id => pending.delete(id)); }).finally(() => { running--; pump(); });
    }
  }
  function wantPhotos(ids) { ids.forEach(id => { if (!pending.has(id)) { pending.add(id); queue.push(id); } }); pump(); }

  /* ---------- cloud implementation (same method names as the local database) ---------- */
  const keyOf = u => String(u == null ? '' : u).trim().toLowerCase();
  const Cloud = {
    async ensureSeed() { /* the server creates the first administrator */ },
    async rev() { return (await api('GET', '/rev')).rev; },

    async login(username, password) {
      const out = await api('POST', '/login', { username, password, deviceId: deviceId() });
      localStorage.setItem(TOKEN_KEY, out.token);
      const sess = JSON.stringify({ key: out.user.key, t: Date.now() });
      localStorage.setItem('fs_session', sess); sessionStorage.setItem('fs_session', sess);
      return out.user;
    },
    async currentUser() {
      if (!getTok()) return null;
      try { return (await api('GET', '/me')).user; }
      catch (e) {
        if (e.status === 401) { Cloud.logout(true); return null; }
        throw e;
      }
    },
    logout(skipServer) {
      const t = getTok();
      if (t && !skipServer) { try { fetch('/api/logout', { method: 'POST', headers: { Authorization: 'Bearer ' + t }, keepalive: true }); } catch (e) { /* ignore */ } }
      localStorage.removeItem(TOKEN_KEY); localStorage.removeItem('fs_session'); sessionStorage.removeItem('fs_session');
    },

    async allUsers() { return (await api('GET', '/users')).users; },
    async createUser(u) { await api('POST', '/users', u); },
    async updateUser(key, patch) { return (await api('PATCH', '/users/' + encodeURIComponent(keyOf(key)), patch)).user; },
    async removeUser(key) { await api('DELETE', '/users/' + encodeURIComponent(keyOf(key))); },
    async userDevices(key) { return await api('GET', '/users/' + encodeURIComponent(keyOf(key)) + '/devices'); },
    async releaseDevice(key, id) { await api('DELETE', '/users/' + encodeURIComponent(keyOf(key)) + '/devices' + (id ? '/' + encodeURIComponent(id) : '')); },
    async setPassword(key, password) { await api('POST', '/users/' + encodeURIComponent(keyOf(key)) + '/password', { password }); },
    async changePassword(key, current, next) { await api('POST', '/me/password', { current, next }); },

    async reports() {
      await warm();
      const list = (await api('GET', '/reports')).reports;
      const need = [];
      list.forEach(r => {
        if (!r.has_photo) { r.photo = null; return; }
        const c = mem.get(r.id);
        if (c && c.rev === r.photoRev) r.photo = c.data;       // photo not set while still downloading (so a save never deletes it)
        else need.push(r.id);
      });
      if (need.length) wantPhotos(need);
      return list;
    },
    async getReport(id) {
      try {
        const r = (await api('GET', '/reports/' + encodeURIComponent(id))).report;
        if (r.photo) await cachePut(r.id, r.photoRev, r.photo);
        return r;
      } catch (e) { if (e.status === 404) return null; throw e; }
    },
    async saveReport(r) {
      if (!r || !r.id) throw new Error('Report id is required.');
      const body = Object.assign({}, r); delete body.has_photo; delete body.updatedAt; delete body.photoRev;
      if ('photo' in body) {
        if (typeof body.photo === 'string' && body.photo.startsWith('data:')) {
          const c = mem.get(r.id); if (c && c.data === body.photo) delete body.photo;  // unchanged - do not re-upload
        } else if (body.photo === undefined) delete body.photo;
        else body.photo = null;                                                         // explicit removal
      }
      const out = await api('PUT', '/reports/' + encodeURIComponent(r.id), body);
      if ('photo' in body) { if (body.photo) await cachePut(r.id, out.updatedAt, body.photo); else await cacheDel(r.id); }
    },
    async deleteReport(id) { await api('DELETE', '/reports/' + encodeURIComponent(id)); await cacheDel(id); },

    async logActivity(username, action, detail, reportId) { try { await api('POST', '/activity', { action, detail, reportId }); } catch (e) { /* non-critical */ } },
    async activityLogs(opts) {
      opts = opts || {}; const q = [];
      if (opts.username) q.push('username=' + encodeURIComponent(opts.username));
      if (opts.since) q.push('since=' + encodeURIComponent(opts.since));
      q.push('limit=' + (opts.limit || 300));
      return (await api('GET', '/activity?' + q.join('&'))).logs;
    },
    async userFootprint(username) {
      const key = username || '';
      const logs = await Cloud.activityLogs({ username: key, limit: 200 });
      const reps = (await Cloud.reports()).filter(r => (r.createdBy || '') === key || (r.catcher || '') === key);
      return { logs, reports: reps };
    },
    async storageInfo() { return { used: 0, quota: 0, persistent: true, note: 'Shared cloud database (Cloudflare D1) - the same data on every device' }; },

    /* ----- backup / restore ----- */
    async exportAll() {
      const users = (await api('GET', '/admin/users')).users;
      const list = (await api('GET', '/reports')).reports;
      const reports = [];
      for (let i = 0; i < list.length; i += 4) {
        const part = await Promise.all(list.slice(i, i + 4).map(r => r.has_photo ? Cloud.getReport(r.id) : r));
        part.forEach(x => { if (x) reports.push(x); });
      }
      const activity = (await api('GET', '/activity?limit=5000')).logs;
      return { app: 'fidelity-adt-snake-portal', version: 3, format: 'json', source: 'cloud', exported: new Date().toISOString(), users, reports, activity };
    },
    async importAll(data, replace) {
      if (!data || data.app !== 'fidelity-adt-snake-portal') throw new Error('This is not a portal backup file.');
      if (replace) await api('POST', '/admin/wipe', {});
      for (const u of data.users || []) await api('POST', '/admin/import-user', Object.assign({}, u, { ignoreExisting: !replace }));
      const have = new Set(replace ? [] : (await api('GET', '/reports')).reports.map(r => r.id));
      for (const r of data.reports || []) {
        if (!r || !r.id || have.has(r.id)) continue;
        const b = Object.assign({}, r); delete b.has_photo; delete b.updatedAt; delete b.photoRev;
        if (!(typeof b.photo === 'string' && b.photo.startsWith('data:'))) delete b.photo;
        await api('PUT', '/reports/' + encodeURIComponent(r.id), b);
      }
      const acts = data.activity || [];
      for (let i = 0; i < acts.length; i += 200) await api('POST', '/admin/import-activity', { items: acts.slice(i, i + 200) });
      mem.clear();
    },
    async exportSqlite() { throw new Error('A .sqlite file is only available in local mode. Use the JSON backup for the shared cloud database.'); },
    async importSqlite() { throw new Error('SQLite file restore is only available in local mode. Use a JSON backup.'); },
    async persist() {},
    keyOf,
    async hash() { throw new Error('Not available in cloud mode.'); }
  };

  /* ---------- proxy: picks cloud or local once, then forwards ---------- */
  const METHODS = ['ensureSeed', 'createUser', 'setPassword', 'changePassword', 'updateUser', 'removeUser', 'allUsers', 'login', 'currentUser',
    'logout', 'reports', 'saveReport', 'deleteReport', 'getReport', 'exportAll', 'importAll', 'exportSqlite', 'importSqlite', 'hash',
    'persist', 'userDevices', 'releaseDevice', 'logActivity', 'activityLogs', 'userFootprint', 'storageInfo', 'rev'];

  /* local-mode version of changePassword (verifies the old password in the browser) */
  const Local = () => {
    const L = window.DBLocal;
    if (!L.changePassword) L.changePassword = async (key, current, next) => {
      const u = (await L.allUsers()).find(x => x.key === keyOf(key));
      if (!u || (await L.hash(current, u.salt)) !== u.hash) throw new Error('Current password is incorrect.');
      await L.setPassword(key, next);
    };
    return L;
  };

  let implP = null;
  const Proxy_ = { mode: null, cloudNote: '', onPhotos: null, keyOf };
  function pick() {
    if (!implP) implP = (async () => {
      let health = null;
      try {
        const ctl = new AbortController(); const tm = setTimeout(() => ctl.abort(), 7000);
        const r = await fetch('/api/health', { cache: 'no-store', signal: ctl.signal }); clearTimeout(tm);
        health = await r.json();
      } catch (e) { health = null; }
      if (health && health.ok && health.db) { localStorage.setItem(MODE_KEY, 'cloud'); Proxy_.mode = 'cloud'; return Cloud; }
      if (health && health.ok && !health.db) Proxy_.cloudNote = health.error || 'Cloud database is not connected.';
      // server unreachable but this site used the cloud before: stay in cloud mode so errors are honest (never silently use a private local copy)
      if (!health && localStorage.getItem(MODE_KEY) === 'cloud') { Proxy_.mode = 'cloud'; Proxy_.cloudNote = 'Server temporarily unreachable.'; return Cloud; }
      if (!window.DBLocal) throw new Error('Local database (js/db.js) did not load.');
      Proxy_.mode = 'local'; return Local();
    })();
    return implP;
  }
  Proxy_.logout = () => Cloud.logout();          // synchronous: clears the session before the page navigates away
  METHODS.filter(m => m !== 'logout').forEach(m => { Proxy_[m] = async (...a) => { const impl = await pick(); if (typeof impl[m] !== 'function') throw new Error('Not supported: ' + m); return impl[m](...a); }; });
  Proxy_.photosPending = () => pending.size;
  Proxy_.waitPhotos = async () => { const t0 = Date.now(); while (pending.size && Date.now() - t0 < 90000) await new Promise(r => setTimeout(r, 300)); };
  Proxy_.detect = pick;                          // await DB.detect() to learn DB.mode
  Proxy_.migrateLocalToCloud = async () => {     // copy this device's local users + reports into the shared database
    const impl = await pick(); if (impl !== Cloud) throw new Error('The shared cloud database is not connected.');
    const local = window.DBLocal; if (!local) throw new Error('Local database not available.');
    const data = await local.exportAll();
    await Cloud.importAll(data, false);
    return { users: (data.users || []).length, reports: (data.reports || []).length };
  };
  window.DB = Proxy_;
})();
