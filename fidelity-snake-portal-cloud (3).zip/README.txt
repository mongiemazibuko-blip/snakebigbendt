FIDELITY SERVICES GROUP - ESWATINI (BIGBEND) SNAKE CATCHERS PORTAL - Cloudflare Pages + shared cloud database (D1)

WHY ONE DEVICE'S USERS DID NOT WORK ON ANOTHER
Before the cloud database is connected, every browser keeps its own private copy of the data.
With the steps below, ALL devices share one database: a user created once can sign in anywhere,
and every capture/release is visible to everyone within seconds.

SET UP (about 5 minutes, all in the Cloudflare dashboard - no command line)
 1. Create the database:  Cloudflare dashboard > Storage & Databases > D1 SQL Database > Create database.
    Name it  fidelity-snake-portal  . (No SQL to run - the portal creates its own tables.)
 2. Upload the site:  Workers & Pages > Create > Pages > Upload assets. Upload the CONTENTS of this folder
    (index.html, login.html, 404.html, _worker.js, _headers, css, js, assets) and Deploy.
    index.html must be at the top level of the upload.
 3. Connect the database:  open the Pages project > Settings > Bindings > Add > D1 database.
       Variable name :  PORTAL_DB      (exactly, capital letters)
       D1 database   :  fidelity-snake-portal
    Save (add it for Production).
 4. Re-deploy so the binding takes effect:  Deployments > Create new deployment (upload the same folder again),
    or Retry deployment on the latest one.
 5. Open  https://<your-project>.pages.dev/login.html
    A GREEN box must say "Connected to the shared cloud database". (Yellow = still local mode: repeat steps 3-4.)
 6. Sign in:  Mongi / Toor007  - then Settings > change the password.
    Optional: before step 4 add environment variables ADMIN_USERNAME / ADMIN_PASSWORD (Settings > Variables)
    to choose the first administrator's password instead of Toor007.

KEEP WHAT YOU ALREADY CREATED
 Users/reports saved earlier on a phone or PC live only in that browser. On that device: sign in as Mongi >
 Settings > "Upload this device's data to the cloud" (once). Users created there can then sign in on any device
 with their old password (it is upgraded to a stronger hash on first login). If one cannot, use Users > Reset password.

DEVICE LIMIT (new)
 Normal users can be signed in on 2 devices (browsers) at a time; a third sign-in is refused with a clear message.
 Administrators have no limit. Signing out frees that slot. Admin > Users > Devices shows each user's signed-in
 devices and can release one or all. To change the number, add environment variable MAX_USER_DEVICES (default 2).
 Note: a device = one browser profile. Clearing browser data counts as a new device until it is released.
 Existing sign-ins keep working; the column is added to the database automatically on the first request.

ACCESS LEVELS
 Admin : everything, plus Users (add / remove / reset password / change level), backups and restore.
 User  : register captures, view map and reports, mark releases, export, share, delete their own reports.
 Rules are enforced by the server, not just the screen.

SECURITY
 Passwords are hashed on the server (PBKDF2-SHA256), sign-in sessions last 30 days, 5 wrong passwords lock that
 username for 60 seconds. Raise PBKDF2_ITER (variable) on a paid Workers plan for even stronger hashing.

BACKUPS
 Settings > Download JSON backup (users, reports, photos, activity). Restore works on any portal (merge or replace).

LIMITS (free Cloudflare plan)
 ~100,000 requests/day, D1 storage 5 GB. Devices poll once every 15 s only while the tab is open, using a tiny
 change-counter request. Photos are compressed to about 100-150 KB each; the maximum per photo is about 1.8 MB.

IF SOMETHING GOES WRONG
 - "js/db.js ... missing": re-upload the complete folder (js folder included).
 - Yellow "Local mode" banner: the D1 binding is not connected or the project was not re-deployed after adding it.
 - "Cannot reach the portal server": check the internet connection; the portal keeps using the cloud once it has seen it.
 - Maps, Excel, PDF, PowerPoint libraries load from cdnjs/jsDelivr - internet required.
